import unittest
from unittest.mock import patch
from datetime import datetime, timezone
from urllib.error import URLError
from rail_feed import RailFeed, normalize_records

class FeedTests(unittest.TestCase):
    def test_fresh_stale_missing_and_expired(self):
        now = datetime(2026, 10, 10, 1, 0, tzinfo=timezone.utc)
        records = [
            {'@type':'odpt:Train', 'dc:date':'2026-10-10T09:59:30+09:00', 'odpt:trainNumber':'100', 'odpt:frequency':60},
            {'@type':'odpt:Train', 'dc:date':'2026-10-10T09:00:00+09:00'},
            {'@type':'odpt:Train'},
            {'@type':'odpt:Train', 'dc:date':'2026-10-10T10:00:00+09:00', 'dct:valid':'2026-10-10T09:59:00+09:00'},
            {'@type':'odpt:Train', 'dc:date':'not-a-date'},
        ]
        trains, interval = normalize_records(records, now)
        self.assertEqual([t['freshness'] for t in trains], ['RECENT_INFORMATIONAL','STALE','UNKNOWN','STALE','UNKNOWN'])
        self.assertEqual(interval, 60)
        self.assertEqual(trains[0]['age_seconds'], 30)

    @patch('rail_feed.load_local_settings')
    @patch.dict('os.environ', {}, clear=True)
    def test_unconfigured_never_fetches(self, _):
        with patch('rail_feed.urlopen') as get:
            self.assertEqual(RailFeed().get()['status'], 'UNCONFIGURED')
            get.assert_not_called()

    @patch('rail_feed.load_local_settings')
    @patch.dict('os.environ', {'ODPT_CONSUMER_KEY':'private-test-key', 'ODPT_FEED_ENABLED':'true', 'ODPT_OPERATOR':'odpt.Operator:Test'}, clear=True)
    def test_error_does_not_disclose_key_or_show_old_data(self, _):
        with patch('rail_feed.urlopen', side_effect=URLError('https://host/?key=private-test-key')) as get:
            feed = RailFeed()
            response = feed.get()
            self.assertEqual(response['status'], 'UNAVAILABLE')
            self.assertNotIn('private-test-key', str(response))
            self.assertEqual(response['trains'], [])
            feed.get()
            self.assertEqual(get.call_count, 1)

    def test_frequency_and_unknown_shape(self):
        records = [{'@type':'odpt:Train','odpt:frequency':180}]
        self.assertEqual(normalize_records(records, datetime.now(timezone.utc))[1], 180)
        with self.assertRaises(ValueError): normalize_records({}, datetime.now(timezone.utc))

if __name__ == '__main__': unittest.main()
