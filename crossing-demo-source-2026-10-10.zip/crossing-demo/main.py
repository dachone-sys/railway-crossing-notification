"""ASGI entry point for the crossing-watch API."""

from app_v2 import app

__all__ = ["app"]
