@echo off
cd /d "%~dp0frontend"
echo Starting the proposal demo. Open the Local URL shown below.
call npm.cmd run dev -- --host 127.0.0.1
pause
