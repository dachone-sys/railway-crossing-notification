import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
const source = fs.readFileSync(new URL('./src/deviceModel.ts', import.meta.url), 'utf8');
const js = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.ESNext } }).outputText;
const { displayDecision } = await import(`data:text/javascript;base64,${Buffer.from(js).toString('base64')}`);
const base = { phase: 'normal', warningSeconds: 100, uncertainty: 15, replayTime: 100, feedLost: false, stale: false, exitBlocked: false, recovered: true };
assert.equal(displayDecision(base).state, 'green');
assert.equal(displayDecision({ ...base, warningSeconds: 35 }).state, 'amber');
assert.equal(displayDecision({ ...base, warningSeconds: 35.01 }).state, 'green');
for (const patch of [{feedLost:true}, {stale:true}, {recovered:false}, {warningSeconds:null}, {warningSeconds:NaN}, {warningSeconds:Infinity}, {uncertainty:NaN}, {uncertainty:-1}, {replayTime:NaN}, {replayTime:-1}, {replayTime:3600}]) {
 const r=displayDecision({...base,...patch}); assert.equal(r.state,'gray'); assert.equal(r.countdown,null);
}
assert.equal(displayDecision({...base,phase:'prepare'}).state,'amber');
for(const patch of [{phase:'closed',feedLost:true},{exitBlocked:true,stale:true}]) {
 const r=displayDecision({...base,...patch}); assert.equal(r.state,'red'); assert.equal(r.countdown,null);
}
assert.equal(displayDecision({...base,feedLost:false,recovered:false}).state,'gray','clearing fault does not acknowledge recovery');
assert.equal(displayDecision({...base,warningSeconds:100.9}).countdown,100);
assert.equal(displayDecision({...base,warningSeconds:-1}).state,'amber');
const budget=JSON.parse(fs.readFileSync(new URL('./src/deploymentBudget.json',import.meta.url),'utf8'));
assert.equal(budget.items.reduce((sum,r)=>sum+r.low,0),budget.subtotalLow);
assert.equal(budget.items.reduce((sum,r)=>sum+r.high,0),budget.subtotalHigh);
assert.equal(budget.subtotalLow*(1+budget.contingencyRate),budget.totalLow);
assert.equal(budget.subtotalHigh*(1+budget.contingencyRate),budget.totalHigh);
console.log('Display decision: fault, alarm, missing prediction, recovery and time bounds passed. Budget arithmetic passed.');
