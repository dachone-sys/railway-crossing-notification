import assert from 'node:assert/strict';
import fs from 'node:fs';
import ts from 'typescript';
const source = fs.readFileSync(new URL('./src/proposalModel.ts', import.meta.url), 'utf8');
const js = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.ESNext } }).outputText;
const { defaults, safetyDefaults, simulate, assessSafety } = await import(`data:text/javascript;base64,${Buffer.from(js).toString('base64')}`);
const policies = ['current', 'notice', 'signal'];
for (const demand of [0, 300, 600, 1200]) {
  const runs = policies.map(policy => simulate({ ...defaults, demand }, policy));
  for (const r of runs) {
    assert.ok(Math.abs(r.arrived - r.passed - r.remaining) < 1e-7, 'vehicle conservation');
    assert.ok(r.meanDelay >= 0 && r.remaining >= 0);
    if (!demand) assert.equal(r.meanDelay, 0);
  }
  assert.ok(runs[0].meanDelay >= runs[1].meanDelay - 1e-8);
  assert.ok(runs[1].meanDelay >= runs[2].meanDelay - 1e-8);
}
const equal = policies.map(policy => simulate({ ...defaults, slowHeadway: defaults.stopHeadway }, policy));
assert.ok(equal.every(r => Math.abs(r.meanDelay - equal[0].meanDelay) < 1e-8));
assert.equal(simulate(defaults, 'current').capacity, 585);
assert.ok(Math.abs(simulate(defaults, 'notice').capacity - 915) < 1e-8);
assert.equal(simulate(defaults, 'signal').capacity, 975);
assert.ok(simulate({ ...defaults, demand: 1200 }, 'signal').overloaded);
assert.equal(simulate({ ...defaults, lead: 0 }, 'notice').meanDelay, simulate(defaults, 'signal').meanDelay);
assert.throws(() => simulate({ ...defaults, cycle: 0 }, 'notice'));
assert.equal(assessSafety(safetyDefaults, 30).eligible, true);
for (const patch of [{ connected: false }, { age: 3.01 }, { sensor: false }, { alarm: true }, { gateOpen: false }, { exitClear: false }, { obstacle: true }, { recovered: false }, { secondsToWarning: 30 }]) {
  const decision = assessSafety({ ...safetyDefaults, ...patch }, 30);
  assert.equal(decision.eligible, false);
  assert.ok(decision.reasons.length > 0);
}
assert.equal(assessSafety({ ...safetyDefaults, uncertainty: 45 }, 30).threshold, 65);
assert.equal(assessSafety({ ...safetyDefaults, age: 3, secondsToWarning: 31 }, 30).eligible, true);
assert.equal(assessSafety({ ...safetyDefaults, secondsToWarning: NaN }, 30).eligible, false);
console.log('PASS: conservation, capacity, overload, no-benefit case, boundary and fault scenarios');
console.log(JSON.stringify(policies.map(policy => simulate(defaults, policy)).map(({trace, ...summary}) => summary), null, 2));
