export type Crossing = {
  crossing_id: string;
  name: string;
  operator: string;
  line: string;
  municipality: string;
  address: string;
  latitude: number;
  longitude: number;
  location_accuracy: string;
  official_note: string;
};

type Props = {
  crossings: Crossing[];
  selectedId: string;
  onSelect: (id: string) => void;
};

function CrossingMap({ crossings, selectedId, onSelect }: Props) {
  const selected = crossings.find((item) => item.crossing_id === selectedId) || crossings[0];
  if (!selected) return null;
  const deltaLat = 0.009;
  const deltaLon = 0.014;
  const bbox = [selected.longitude - deltaLon, selected.latitude - deltaLat, selected.longitude + deltaLon, selected.latitude + deltaLat].join(",");
  const mapUrl = `https://www.openstreetmap.org/export/embed.html?bbox=${encodeURIComponent(bbox)}&layer=mapnik&marker=${selected.latitude},${selected.longitude}`;
  const fullMapUrl = `https://www.openstreetmap.org/?mlat=${selected.latitude}&mlon=${selected.longitude}#map=16/${selected.latitude}/${selected.longitude}`;

  return (
    <section className="mapSection">
      <div className="mapHeading">
        <div><span className="sectionLabel">CROSSING MAP</span><h2>監視する踏切を選ぶ</h2></div>
        <span>海老名エリア・実在候補</span>
      </div>
      <div className="mapLayout">
        <div className="mapFrame">
          <iframe title={`${selected.name} 周辺地図`} src={mapUrl} loading="lazy" />
          <a href={fullMapUrl} target="_blank" rel="noreferrer">OpenStreetMapで確認 ↗</a>
        </div>
        <div className="crossingSelector">
          {crossings.map((crossing) => (
            <button key={crossing.crossing_id} className={crossing.crossing_id === selected.crossing_id ? "selected" : ""} onClick={() => onSelect(crossing.crossing_id)}>
              <span className="railOperator">{crossing.operator}・{crossing.line}</span>
              <strong>{crossing.name}</strong>
              <small>{crossing.address}</small>
              <em>{crossing.official_note}</em>
            </button>
          ))}
        </div>
      </div>
      <p className="coordinateNotice">位置は公開資料からの概略です。実証前に現地測量と鉄道・道路管理者の確認が必要です。</p>
    </section>
  );
}

export default CrossingMap;
