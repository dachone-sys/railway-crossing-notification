import type { Dataset } from './timetableModel';
export const officialTimetable: Dataset = {
  "title": "小田急公式・海老名上り／座間下り 発車ダイヤ抜粋",
  "checkedOn": "2026-10-10",
  "coverage": "10時台の駅発車ダイヤ抜粋。海老名上りは直前の1本も収録。座間を通過する下り急行・快速急行・特急等は未収録。踏切を通る全列車のダイヤではありません。",
  "sources": [
    {
      "station": "海老名",
      "direction": "up",
      "day": "holiday",
      "revision": "2026-03-14",
      "url": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf",
      "sha256": "229812789e1e42b5b6e2ff42f66b1acbc7545f711a2cbb26197b798ce0850c21"
    },
    {
      "station": "海老名",
      "direction": "up",
      "day": "weekday",
      "revision": "2026-03-16",
      "url": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf",
      "sha256": "f463eb95b434e09b2f5346fef351cfd4f9cfc773c42e22708d1b682f79c3cf66"
    },
    {
      "station": "座間",
      "direction": "down",
      "day": "holiday",
      "revision": "2026-03-14",
      "url": "https://www.odakyu.jp/station/zama/timetable_down_holiday.pdf",
      "sha256": "1cfd5117d38ac7bef4b1d4420a4390ff7f45bd49dce2fb566f0c2ecc7ff9c3d3"
    },
    {
      "station": "座間",
      "direction": "down",
      "day": "weekday",
      "revision": "2026-03-16",
      "url": "https://www.odakyu.jp/station/zama/timetable_down_weekday.pdf",
      "sha256": "b6213c1110527f2f9da589522fd786919bb0a6cbf9ce1da0e52069170289bc4a"
    }
  ],
  "departures": [
    {
      "id": "ebina-holiday-0955",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "09:55",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1002",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:02",
      "kind": "快速急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1006",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:06",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1011",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:11",
      "kind": "急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1014",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:14",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1019",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:19",
      "kind": "快速急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1023",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:23",
      "kind": "特急",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1027",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:27",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1032",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:32",
      "kind": "急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1037",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:37",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1043",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:43",
      "kind": "快速急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1046",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:46",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1051",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:51",
      "kind": "急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-holiday-1055",
      "day": "holiday",
      "direction": "up",
      "station": "海老名",
      "time": "10:55",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_holiday.pdf"
    },
    {
      "id": "ebina-weekday-0958",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "09:58",
      "kind": "快速急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1000",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:00",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1009",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:09",
      "kind": "急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1011",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:11",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1018",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:18",
      "kind": "快速急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1020",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:20",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1027",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:27",
      "kind": "特急",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1030",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:30",
      "kind": "急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1031",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:31",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1038",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:38",
      "kind": "快速急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1040",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:40",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1049",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:49",
      "kind": "急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1051",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:51",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "ebina-weekday-1058",
      "day": "weekday",
      "direction": "up",
      "station": "海老名",
      "time": "10:58",
      "kind": "快速急行",
      "sourceUrl": "https://www.odakyu.jp/station/ebina/timetable_up_weekday.pdf"
    },
    {
      "id": "zama-holiday-1002",
      "day": "holiday",
      "direction": "down",
      "station": "座間",
      "time": "10:02",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_holiday.pdf"
    },
    {
      "id": "zama-holiday-1008",
      "day": "holiday",
      "direction": "down",
      "station": "座間",
      "time": "10:08",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_holiday.pdf"
    },
    {
      "id": "zama-holiday-1021",
      "day": "holiday",
      "direction": "down",
      "station": "座間",
      "time": "10:21",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_holiday.pdf"
    },
    {
      "id": "zama-holiday-1031",
      "day": "holiday",
      "direction": "down",
      "station": "座間",
      "time": "10:31",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_holiday.pdf"
    },
    {
      "id": "zama-holiday-1040",
      "day": "holiday",
      "direction": "down",
      "station": "座間",
      "time": "10:40",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_holiday.pdf"
    },
    {
      "id": "zama-holiday-1053",
      "day": "holiday",
      "direction": "down",
      "station": "座間",
      "time": "10:53",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_holiday.pdf"
    },
    {
      "id": "zama-weekday-1003",
      "day": "weekday",
      "direction": "down",
      "station": "座間",
      "time": "10:03",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_weekday.pdf"
    },
    {
      "id": "zama-weekday-1011",
      "day": "weekday",
      "direction": "down",
      "station": "座間",
      "time": "10:11",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_weekday.pdf"
    },
    {
      "id": "zama-weekday-1019",
      "day": "weekday",
      "direction": "down",
      "station": "座間",
      "time": "10:19",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_weekday.pdf"
    },
    {
      "id": "zama-weekday-1029",
      "day": "weekday",
      "direction": "down",
      "station": "座間",
      "time": "10:29",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_weekday.pdf"
    },
    {
      "id": "zama-weekday-1041",
      "day": "weekday",
      "direction": "down",
      "station": "座間",
      "time": "10:41",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_weekday.pdf"
    },
    {
      "id": "zama-weekday-1049",
      "day": "weekday",
      "direction": "down",
      "station": "座間",
      "time": "10:49",
      "kind": "各駅停車",
      "sourceUrl": "https://www.odakyu.jp/station/zama/timetable_down_weekday.pdf"
    }
  ]
};
