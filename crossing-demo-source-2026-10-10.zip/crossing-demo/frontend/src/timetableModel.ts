export type DayType = 'weekday' | 'holiday';
export type Direction = 'up' | 'down';
export type Departure = {
  id: string; day: DayType; direction: Direction; station: '海老名' | '座間';
  time: string; kind: string; sourceUrl: string;
};
export type Source = { station: string; direction: Direction; day: DayType; revision: string; url: string; sha256: string };
export type Dataset = { title: string; checkedOn: string; coverage: string; sources: Source[]; departures: Departure[] };
export type Arrival = Departure & { departure: number; arrival: number };
export const startOfWindow = 10 * 3600;
export function timeSeconds(time: string): number {
  if (!/^\d{2}:\d{2}(:\d{2})?$/.test(time)) throw new Error('時刻はHH:mmまたはHH:mm:ssで指定してください');
  const [h, m, s = 0] = time.split(':').map(Number);
  if (h > 29 || m > 59 || s > 59) throw new Error('時刻が範囲外です（時は00〜29）');
  return h * 3600 + m * 60 + s;
}
export function displayTime(seconds: number) {
  const total = Math.round(startOfWindow + seconds);
  const pad = (v: number) => String(v).padStart(2, '0');
  return `${pad(Math.floor(total / 3600))}:${pad(Math.floor(total % 3600 / 60))}:${pad(total % 60)}`;
}
export function arrivalsFor(departures: Departure[], day: DayType, upTravel: number, downTravel: number, delay: number): Arrival[] {
  return departures.filter(d => d.day === day).map(d => {
    const departure = timeSeconds(d.time) - startOfWindow;
    return { ...d, departure, arrival: departure + (d.direction === 'up' ? upTravel : downTravel) + delay };
  }).sort((a, b) => a.arrival - b.arrival);
}
export function mergeIntervals(intervals: [number, number][]): [number, number][] {
  const result: [number, number][] = [];
  for (const [begin, end] of [...intervals].sort((a, b) => a[0] - b[0])) {
    const previous = result[result.length - 1];
    if (previous && begin <= previous[1]) previous[1] = Math.max(previous[1], end);
    else result.push([begin, end]);
  }
  return result;
}
export type Phase = 'normal' | 'prepare' | 'closed';
export function phaseAt(t: number, arrivals: number[], lead: number, before = 35, after = 10): Phase {
  if (arrivals.some(a => t >= a - before && t < a + after)) return 'closed';
  if (arrivals.some(a => t >= a - before - lead && t < a - before)) return 'prepare';
  return 'normal';
}
/** Minimal RFC4180 reader, with quoted commas/newlines and doubled quotes. */
export function readCsv(text: string): string[][] {
  const rows: string[][] = []; let row: string[] = [], cell = '', quoted = false;
  const clean = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < clean.length; i++) {
    const c = clean[i];
    if (c === '"') {
      if (quoted && clean[i + 1] === '"') { cell += '"'; i++; }
      else if (quoted || !cell) quoted = !quoted;
      else throw new Error('CSVの引用符が不正です');
    } else if (c === ',' && !quoted) { row.push(cell); cell = ''; }
    else if ((c === '\n' || c === '\r') && !quoted) {
      if (c === '\r' && clean[i + 1] === '\n') i++;
      row.push(cell); if (row.some(x => x.trim())) rows.push(row); row = []; cell = '';
    } else cell += c;
  }
  if (quoted) throw new Error('CSVの引用符が閉じていません');
  row.push(cell); if (row.some(x => x.trim())) rows.push(row);
  return rows;
}
export function parseDepartureCsv(text: string): Departure[] {
  if (text.length > 1_000_000) throw new Error('CSVは1MB以内にしてください');
  const rows = readCsv(text);
  const header = rows.shift()?.map(s => s.trim()) || [];
  const names = ['id', 'day', 'direction', 'station', 'time', 'kind', 'source_url'];
  if (names.some(n => !header.includes(n))) throw new Error(`必要な列：${names.join(', ')}`);
  if (!rows.length || rows.length > 5000) throw new Error('1〜5000行のデータを指定してください');
  const ids = new Set<string>();
  return rows.map((row, i) => {
    if (row.length !== header.length) throw new Error(`${i + 2}行目の列数が不正です`);
    const get = (name: string) => row[header.indexOf(name)].trim();
    const id = get('id'), day = get('day'), direction = get('direction'), station = get('station');
    if (!id || ids.has(id)) throw new Error(`${i + 2}行目のIDが空または重複しています`);
    ids.add(id);
    if (day !== 'weekday' && day !== 'holiday') throw new Error('dayはweekdayまたはholiday');
    if ((direction !== 'up' || station !== '海老名') && (direction !== 'down' || station !== '座間')) throw new Error('海老名up／座間downの発車データを指定してください');
    timeSeconds(get('time'));
    let url: URL;
    try { url = new URL(get('source_url')); } catch { throw new Error('出典URLが不正です'); }
    if (url.protocol !== 'https:' || url.username || url.password) throw new Error('出典URLは認証情報を含まないhttpsにしてください');
    return { id, day, direction: direction as Direction, station: station as Departure['station'], time: get('time'), kind: get('kind') || '種別不明', sourceUrl: url.href };
  });
}

export function departureCsv(departures: Departure[]): string {
  const quote = (value: string) => /[\r\n",]/.test(value) ? `"${value.replaceAll('"', '""')}"` : value;
  return '\uFEFFid,day,direction,station,time,kind,source_url\r\n' + departures.map(d => [d.id, d.day, d.direction, d.station, d.time, d.kind, d.sourceUrl].map(quote).join(',')).join('\r\n');
}
