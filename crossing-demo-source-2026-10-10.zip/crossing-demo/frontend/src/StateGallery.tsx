const base=import.meta.env.BASE_URL;
const images:Record<string,string>={green:`${base}images/crossing-green.png`,amber:`${base}images/crossing-amber.png`,red:`${base}images/crossing-red.png`,gray:`${base}images/crossing-gray.png`};
export default function StateGallery(){return <section className="card stateGallery"><span className="kicker">資料用 / 4色の上部表示</span><h2>各状態の設置イメージ</h2><p>AI生成の将来構想です。数値は静止画の例。動画とシミュレーションでは分・秒がカウントされます。</p><div>{[
 ['green','緑：徐行の検討領域','警報開始まで1分30秒。遮断機は上がり、警報灯は消灯。'],
 ['amber','黄：毎車一時停止','警報開始まで0分20秒。退出余裕も確認し、無理に進入しない。'],
 ['red','赤：進入禁止','列車通過中。到達カウントは0分00秒。開通までの時間ではありません。'],
 ['gray','灰：補助情報なし','時間表示を停止。現地の信号・警報と通常の一時停止義務に従う。'],
 ].map(([color,title,detail])=><figure key={color}><a href={images[color]} target="_blank" rel="noreferrer"><img loading="lazy" src={images[color]} alt={title}/></a><figcaption><b>{title}</b><p>{detail}</p></figcaption></figure>)}</div></section>}
