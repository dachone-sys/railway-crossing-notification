import { useEffect, useRef, useState } from "react";
import Experience from "./Experience";
import Overview from "./Overview";
import Deployment from "./Deployment";
import Proposal from "./Proposal";
import Evidence from "./Evidence";
import CrossingVisual from "./CrossingVisual";
import CrossingMap, { type Crossing } from "./CrossingMap";
import "./App.css";

type Mode = "SLOW_ALLOWED" | "PREPARE_STOP" | "STOP" | "EMERGENCY_STOP";
type State = {
  crossing_id: string; test_mode: string; cycle_seconds: number; train_schedule: number[];
  name: string; operator: string; line: string; municipality: string; address: string;
  latitude: number; longitude: number; location_accuracy: string; official_note: string;
  data_mode: string; data_source_status: string;
  countdown_seconds: number | null; current_mode: Mode; display_text: string; message: string; time_status_label?: string;
  communication_status: string; sensor_status: string; obstacle_detected: boolean; confidence_score: number;
  vehicle_count: number; waiting_vehicles: number; average_wait_time: number; arriving_vehicles: number;
  passed_vehicles: number; pass_capacity: number; simulation_seconds: number; current_rule_wait_time: number;
  proposed_rule_wait_time: number; improvement_rate: number; evaluation: string; evaluation_level: "HIGH" | "MEDIUM" | "LOW";
  traffic_model: { model_name: string; model_status: string; arrival_rate_vpm: number; saturation_flow_vpm: number;
    volume_capacity_ratio: number; effective_blockage_seconds: number; forecast_max_queue: number;
    forecast_dissipation_seconds: number | null; forecast_total_delay_vehicle_seconds: number | null;
    forecast_average_delay_seconds: number | null; stable: boolean; equations: Record<string, string> };
};
type Alert = { id: number; mode: Mode; title: string; detail: string; time: string };
type Scenario = { name: string; description: string; cycle: number; schedule: number[] };

const scenarios: Scenario[] = [
  { name: "標準", description: "基本的な状態遷移を確認", cycle: 240, schedule: [200] },
  { name: "列車少なめ", description: "余裕時間が長いケース", cycle: 360, schedule: [300] },
  { name: "列車多め", description: "連続接近と混雑を確認", cycle: 240, schedule: [80, 160, 220] },
  { name: "短時間テスト", description: "90秒で全状態を確認", cycle: 90, schedule: [60] },
];
const modeMeta: Record<Mode, { eyebrow: string; icon: string; title: string }> = {
  SLOW_ALLOWED: { eyebrow: "通常監視中", icon: "✓", title: "通常の一時停止を継続" },
  PREPARE_STOP: { eyebrow: "列車接近", icon: "!", title: "停止の準備" },
  STOP: { eyebrow: "踏切遮断中", icon: "×", title: "通行しないでください" },
  EMERGENCY_STOP: { eyebrow: "システム異常", icon: "!", title: "補助情報を確認できません" },
};
const apiOrigin = import.meta.env.VITE_API_ORIGIN || (location.protocol === 'file:' ? 'http://127.0.0.1:8000' : `${location.protocol}//${location.hostname}:8000`);
const wsOrigin = apiOrigin.replace(/^http/, "ws");
const clock = (date: Date) => new Intl.DateTimeFormat("ja-JP", { hour: "2-digit", minute: "2-digit", second: "2-digit" }).format(date);

function App() {
  const [data, setData] = useState<State | null>(null);
  const [crossings, setCrossings] = useState<Crossing[]>([]);
  const [selectedCrossing, setSelectedCrossing] = useState("EBINA-ZAMA14");
  const [connection, setConnection] = useState<"connecting" | "online" | "offline">("connecting");
  const [view, setView] = useState<"overview" | "deployment" | "experience" | "proposal" | "evidence" | "driver" | "admin">("overview");
  const [now, setNow] = useState(() => Date.now());
  const [cycle, setCycle] = useState("240");
  const [schedule, setSchedule] = useState("200");
  const [message, setMessage] = useState("");
  const [updated, setUpdated] = useState<Date | null>(null);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [sound, setSound] = useState(() => localStorage.getItem("crossing-sound") !== "off");
  const [notifications, setNotifications] = useState(() => "Notification" in window && Notification.permission === "granted");
  const previousMode = useRef<Mode | null>(null);
  const retryTimer = useRef<number | null>(null);
  const alertId = useRef(0);
  const soundRef = useRef(sound);
  const notificationsRef = useRef(notifications);

  const api = async (path: string, options?: RequestInit) => {
    const response = await fetch(`${apiOrigin}${path}`, options);
    if (!response.ok) throw new Error(String(response.status));
    return response.json();
  };

  const tone = (mode: Mode) => {
    if (!soundRef.current || mode === "SLOW_ALLOWED") return;
    try {
      const AudioCtor = window.AudioContext || (window as typeof window & { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const audio = new AudioCtor();
      const oscillator = audio.createOscillator();
      const gain = audio.createGain();
      oscillator.frequency.value = mode === "PREPARE_STOP" ? 660 : 440;
      gain.gain.setValueAtTime(0.12, audio.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + 0.45);
      oscillator.connect(gain).connect(audio.destination);
      oscillator.start(); oscillator.stop(audio.currentTime + 0.45);
    } catch { /* visual notification remains available */ }
  };

  const notify = (next: State) => {
    const meta = modeMeta[next.current_mode];
    const item = { id: ++alertId.current, mode: next.current_mode, title: meta.title, detail: next.message, time: clock(new Date()) };
    setAlerts((items) => [item, ...items].slice(0, 8));
    tone(next.current_mode);
    if (next.current_mode !== "SLOW_ALLOWED" && navigator.vibrate) navigator.vibrate([250, 100, 250]);
    if (notificationsRef.current && document.hidden && next.current_mode !== "SLOW_ALLOWED") {
      new Notification(`踏切通知：${meta.title}`, { body: next.message, tag: "crossing-state" });
    }
  };

  const requestNotifications = async () => {
    if (!("Notification" in window)) return setMessage("このブラウザは通知に対応していません");
    const permission = await Notification.requestPermission();
    setNotifications(permission === "granted");
    setMessage(permission === "granted" ? "ブラウザ通知を有効にしました" : "通知が許可されませんでした");
  };

  const post = async (path: string, success: string) => {
    const separator = path.includes("?") ? "&" : "?";
    try { const result = await api(`${path}${separator}crossing_id=${encodeURIComponent(selectedCrossing)}`, { method: "POST" }); setMessage(result.message || success); }
    catch { setMessage("操作に失敗しました。API接続を確認してください"); }
  };

  const sendConfig = async (nextCycle: number, nextSchedule: number[]) => {
    try {
      const result = await api("/api/simulation/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ crossing_id: selectedCrossing, cycle_seconds: nextCycle, train_schedule: nextSchedule }) });
      setMessage(result.message || "設定を更新しました");
    } catch { setMessage("設定を更新できませんでした"); }
  };

  const updateConfig = () => {
    const nextCycle = Number(cycle);
    const nextSchedule = schedule.split(",").map((value) => Number(value.trim())).filter(Number.isInteger);
    if (!Number.isInteger(nextCycle) || nextCycle < 30) return setMessage("周期は30秒以上の整数で入力してください");
    if (!nextSchedule.length || nextSchedule.some((time) => time <= 0 || time >= nextCycle)) return setMessage(`列車時刻は1〜${nextCycle - 1}秒で入力してください`);
    void sendConfig(nextCycle, nextSchedule);
  };

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);
  useEffect(() => {
    soundRef.current = sound;
    localStorage.setItem("crossing-sound", sound ? "on" : "off");
  }, [sound]);
  useEffect(() => { notificationsRef.current = notifications; }, [notifications]);
  useEffect(() => {
    if (view !== "driver" && view !== "admin") return;
    let cancelled = false;
    let timer: number | undefined;
    const loadCrossings = () => {
      api("/api/crossings").then((result) => {
        if (!cancelled) { setCrossings(result.crossings as Crossing[]); setMessage(""); }
      }).catch(() => {
        if (!cancelled) { setMessage("踏切一覧を再取得しています"); timer = window.setTimeout(loadCrossings, 3000); }
      });
    };
    loadCrossings();
    return () => { cancelled = true; if (timer) window.clearTimeout(timer); };
  }, [view]);
  useEffect(() => {
    if (view !== "driver" && view !== "admin") return;
    let socket: WebSocket | null = null;
    let disposed = false;
    let delay = 1000;
    const connect = () => {
      if (disposed) return;
      setConnection("connecting");
      socket = new WebSocket(`${wsOrigin}/ws?crossing_id=${encodeURIComponent(selectedCrossing)}`);
      socket.onopen = () => { if (disposed) return; delay = 1000; setConnection("online"); };
      socket.onmessage = (event) => {
        if (disposed) return;
        try {
          const next = JSON.parse(event.data) as State;
          if (next.crossing_id !== selectedCrossing || !(next.current_mode in modeMeta)) throw new Error("Invalid state");
          setConnection("online"); setData(next); setUpdated(new Date());
          if (previousMode.current && previousMode.current !== next.current_mode) notify(next);
          previousMode.current = next.current_mode;
        } catch { setConnection("offline"); }
      };
      socket.onerror = () => { if (!disposed) setConnection("offline"); };
      socket.onclose = () => {
        if (disposed) return;
        setConnection("offline");
        retryTimer.current = window.setTimeout(connect, delay);
        delay = Math.min(delay * 2, 10000);
      };
    };
    connect();
    return () => { disposed = true; if (retryTimer.current) clearTimeout(retryTimer.current); socket?.close(); };
    // The socket changes only when the selected crossing changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedCrossing, view]);

  const selectCrossing = (crossingId: string) => {
    previousMode.current = null;
    setData(null);
    setAlerts([]);
    setSelectedCrossing(crossingId);
  };
  const unavailable = connection !== "online" || !data || !updated || now - updated.getTime() > 3000;
  const mode: Mode = unavailable ? "EMERGENCY_STOP" : data.current_mode;
  const meta = modeMeta[mode];
  return (
    <main className={`app mode-${mode.toLowerCase()}`}>
      <header className="topbar">
        <a className="brand" href="#top"><span className="brandMark"><i /><i /></span><span>踏切みまもり</span></a>
        <nav className="viewSwitch" aria-label="表示切り替え">
          <button className={view === "overview" ? "active" : ""} onClick={() => setView("overview")}>概要・導入効果</button>
          <button className={view === "experience" ? "active" : ""} onClick={() => setView("experience")}>動く表示・実ダイヤ</button>
          <button className={view === "deployment" ? "active" : ""} onClick={() => setView("deployment")}>費用・期間・許可</button>
          <button className={view === "proposal" ? "active" : ""} onClick={() => setView("proposal")}>詳しい計算</button>
          <button className={view === "evidence" ? "active" : ""} onClick={() => setView("evidence")}>設置・出典</button>
          <select aria-label="APIデモ画面" value={view === "driver" || view === "admin" ? view : ""} onChange={e => { if (e.target.value) setView(e.target.value as "driver" | "admin"); }}><option value="">APIデモ</option><option value="driver">利用者画面</option><option value="admin">管理画面</option></select>
        </nav>
        <div className={`connection ${connection}`}><span />{(view !== "driver" && view !== "admin") ? "ローカル再生・計算" : unavailable ? "補助情報未取得" : "デモAPI接続"}</div>
      </header>

      {view === "overview" ? <Overview navigate={setView} /> : view === "deployment" ? <Deployment /> : view === "experience" ? <Experience /> : view === "proposal" ? <Proposal /> : view === "evidence" ? <Evidence /> : view === "driver" ? <div className="driverPage" id="top">
        <section className="hero" aria-live="assertive">
          <div className="heroContent">
            <div className="statusEyebrow"><span />{unavailable ? "最新情報を取得できません" : meta.eyebrow}</div>
            <div className="statusIcon">{meta.icon}</div>
            <h1>{unavailable ? "情報を確認できません" : meta.title}</h1>
            <p>{unavailable ? "補助情報は利用できません。現地の信号・警報機と一時停止義務に従ってください。" : data?.message || "踏切の状態を取得しています…"}</p>
            {data && !unavailable && <div className="countdownCard"><span>{data.time_status_label || "列車到達まで"}</span><strong>{data.countdown_seconds ?? "未確定"}{data.countdown_seconds !== null && <small>秒</small>}</strong></div>}
          </div>
          <div className="heroRail" aria-hidden="true">{Array.from({ length: 8 }).map((_, i) => <span key={i} />)}</div>
        </section>

        <CrossingMap crossings={crossings} selectedId={selectedCrossing} onSelect={selectCrossing} />

        <section className="contentGrid">
          <article className="card crossingCard">
            <div className="cardHeader"><div><span className="sectionLabel">MONITORING</span><h2>監視中の踏切</h2></div><b className="crossingId">{data?.crossing_id || "--"}</b></div>
            <div className="locationRow"><span>●</span><div><strong>{data?.name || "選択中の踏切"}</strong><small>{data ? `${data.operator}・${data.line}` : "情報を取得中"}</small></div></div>
            {data && <div className="sourceNotice"><b>実在地点＋シミュレーション</b><span>{data.data_source_status}</span></div>}
            <div className="statusList">
              <div><span>通信</span><strong className={!unavailable && data?.communication_status === "NORMAL" ? "ok" : "danger"}>{unavailable ? "未確認" : data?.communication_status === "NORMAL" ? "正常" : "異常"}</strong></div>
              <div><span>センサー</span><strong className={!unavailable && data?.sensor_status === "NORMAL" ? "ok" : "danger"}>{unavailable ? "未確認" : data?.sensor_status === "NORMAL" ? "正常" : "異常"}</strong></div>
              <div><span>デモ判定スコア（安全確率ではありません）</span><strong>{data ? `${Math.round(data.confidence_score * 100)}%` : "--"}</strong></div>
            </div>
          </article>

          <article className="card notifyCard">
            <div className="cardHeader"><div><span className="sectionLabel">ALERTS</span><h2>通知設定</h2></div></div><p>状態が変わったときだけお知らせします。</p>
            <button className={`settingRow ${notifications ? "enabled" : ""}`} onClick={requestNotifications}><b>▣</b><span><strong>ブラウザ通知</strong><small>{notifications ? "許可済み" : "タップして有効化"}</small></span><em>{notifications ? "ON" : "OFF"}</em></button>
            <button className={`settingRow ${sound ? "enabled" : ""}`} onClick={() => setSound((value) => !value)}><b>♪</b><span><strong>通知音・振動</strong><small>接近・遮断・異常時</small></span><em>{sound ? "ON" : "OFF"}</em></button>
          </article>

          <article className="card historyCard">
            <div className="cardHeader"><div><span className="sectionLabel">HISTORY</span><h2>通知履歴</h2></div><button className="textButton" onClick={() => setAlerts([])}>消去</button></div>
            {alerts.length ? <ul>{alerts.slice(0, 4).map((alert) => <li key={alert.id}><i className={alert.mode.toLowerCase()} /><div><strong>{alert.title}</strong><small>{alert.detail}</small></div><time>{alert.time}</time></li>)}</ul> : <div className="emptyState"><span>✓</span><p>まだ通知はありません</p><small>状態の変化がここに記録されます</small></div>}
          </article>
        </section>
        <section className="safetyNotice"><strong>安全のために</strong><p>この画面は実証・シミュレーション用の補助情報です。実際の通行では、必ず現地の警報機・遮断機・道路標識を確認し、道路交通法に従ってください。</p></section>
        {message && <div className="toast" role="status">{message}</div>}
        <footer>最終更新：{updated ? clock(updated) : "--:--:--"} ・ 更新時刻を確認してください</footer>
      </div> : <div className="adminPage">
        <div className="adminHeading"><div><span className="sectionLabel">CONTROL CENTER</span><h1>踏切モニタリング</h1><p>状態監視とシミュレーション設定</p></div><b className="modeBadge">{data?.test_mode || "接続待ち"}</b></div>
        <CrossingMap crossings={crossings} selectedId={selectedCrossing} onSelect={selectCrossing} />
        <section className="metricGrid">
          <article><span>現在の状態</span><strong>{meta.title}</strong><small>{data?.time_status_label || "--"} {data ? `${data.countdown_seconds}秒` : ""}</small></article>
          <article><span>待機車両</span><strong>{data?.waiting_vehicles ?? "--"}<em>台</em></strong><small>累計通過 {data?.vehicle_count ?? "--"}台</small></article>
          <article><span>予測平均遅れ</span><strong>{data?.traffic_model.forecast_average_delay_seconds ?? "--"}<em>秒</em></strong><small>最大車列 {data?.traffic_model.forecast_max_queue ?? "--"}台</small></article>
          <article><span>稼働時間</span><strong>{data?.simulation_seconds ?? "--"}<em>秒</em></strong><small>{data?.evaluation || "評価待ち"}</small></article>
        </section>
        {data && <CrossingVisual currentMode={mode} waitingVehicles={data.waiting_vehicles} />}
        {data && <section className="modelPanel">
          <div className="modelTitle"><div><span className="sectionLabel">QUEUE THEORY</span><h2>渋滞発生モデル</h2></div><b>{data.traffic_model.model_status}</b></div>
          <p>遮断中は流出がゼロになり車列が増加し、開通後は飽和交通流率と到着率の差で解消します。総遅れは累積到着線と累積出発線の間の面積です。</p>
          <div className="modelMetrics"><div><span>到着率 λ</span><strong>{data.traffic_model.arrival_rate_vpm} 台/分</strong></div><div><span>飽和交通流 μ</span><strong>{data.traffic_model.saturation_flow_vpm} 台/分</strong></div><div><span>需要/容量</span><strong>{data.traffic_model.volume_capacity_ratio}</strong></div><div><span>車列解消予測</span><strong>{data.traffic_model.forecast_dissipation_seconds ?? "∞"} 秒</strong></div></div>
          <code>Q(t+Δt) = max(0, Q(t) + (λ − μ(t))Δt)</code>
          <div className="modelFoot">使用中：{data.traffic_model.model_name} ・ 有効遮断時間 {data.traffic_model.effective_blockage_seconds}秒</div>
        </section>}
        <section className="adminGrid">
          <article className="card configBox"><div className="cardHeader"><div><span className="sectionLabel">SCENARIO</span><h2>シミュレーション設定</h2></div></div>
            <div className="scenarioGrid">{scenarios.map((item) => <button key={item.name} onClick={() => { setCycle(String(item.cycle)); setSchedule(item.schedule.join(",")); void sendConfig(item.cycle, item.schedule); }}><strong>{item.name}</strong><small>{item.description}</small><span>{item.cycle}秒 / {item.schedule.join(", ")}秒地点</span></button>)}</div>
            <div className="formGrid"><label>周期（秒）<input inputMode="numeric" value={cycle} onChange={(e) => setCycle(e.target.value)} /></label><label>列車到達地点（カンマ区切り）<input value={schedule} onChange={(e) => setSchedule(e.target.value)} /></label></div><button className="primaryButton" onClick={updateConfig}>設定を反映</button>
          </article>
          <article className="card testBox"><div className="cardHeader"><div><span className="sectionLabel">FAIL-SAFE TEST</span><h2>異常モード</h2></div></div><p>安全側に切り替わることを確認します。</p>
            <div className="testButtons"><button onClick={() => void post("/api/test-mode/NORMAL", "正常に戻しました")}>正常に戻す</button><button onClick={() => void post("/api/test-mode/COMMUNICATION_ERROR", "通信異常")}>通信異常</button><button onClick={() => void post("/api/test-mode/SENSOR_ERROR", "センサー異常")}>センサー異常</button><button onClick={() => void post("/api/test-mode/OBSTACLE", "障害物検知")}>障害物検知</button><button onClick={() => void post("/api/test-mode/LOW_CONFIDENCE", "信頼度低下")}>信頼度低下</button></div>
            <button className="secondaryButton" onClick={() => { setAlerts([]); void post("/api/simulation/reset", "リセットしました"); }}>シミュレーションをリセット</button>
          </article>
        </section>{message && <div className="toast" role="status">{message}</div>}
      </div>}
    </main>
  );
}
export default App;
