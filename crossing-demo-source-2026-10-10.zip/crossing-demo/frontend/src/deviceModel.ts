/** Explanation-only display decision. Never outputs a railway control command. */
export type DisplayInput = {
  phase: 'normal' | 'prepare' | 'closed'; warningSeconds: number | null;
  uncertainty: number; replayTime: number; feedLost: boolean; stale: boolean;
  exitBlocked: boolean; recovered: boolean;
};
export function displayDecision(i: DisplayInput) {
  // A known alarm/blocked exit outranks the availability of a prediction.
  if (i.phase === 'closed' || i.exitBlocked) return { state: 'red', label: i.exitBlocked ? '出口詰まり・進入不可（想定）' : '警報・遮断中（想定）', countdown: null };
  if (!Number.isFinite(i.replayTime) || i.replayTime < 0 || i.replayTime >= 3600 ||
      i.warningSeconds === null || !Number.isFinite(i.warningSeconds) ||
      !Number.isFinite(i.uncertainty) || i.uncertainty < 0 ||
      i.feedLost || i.stale || !i.recovered)
    return { state: 'gray', label: i.feedLost ? '情報途絶・補助情報なし' : i.stale ? '古い情報・補助情報なし' : !i.recovered ? '復旧確認待ち' : '補助情報を確認できません', countdown: null };
  const countdown = Math.max(0, Math.floor(i.warningSeconds));
  if (i.phase === 'prepare' || i.warningSeconds <= Math.max(30, i.uncertainty + 12 + 8))
    return { state: 'amber', label: '一時停止の領域（想定）', countdown };
  return { state: 'green', label: '徐行の検討領域（将来構想）', countdown };
}

