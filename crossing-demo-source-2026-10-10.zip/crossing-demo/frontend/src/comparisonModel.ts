/** Deterministic educational vehicle model. Not connected to railway equipment. */
export type ComparisonPolicy = 'current' | 'notice' | 'signal';
export type Vehicle = { id: number; arrival: number; entry: number | null; stopped: boolean };
export type VehicleParameters = { demand: number; stopHeadway: number; slowHeadway: number; dwell: number; clearance: number; margin: number; lead: number; horizon: number; fallback: boolean; blocked: boolean };
export type VehicleRun = { policy: ComparisonPolicy; params: VehicleParameters; arrivals: number[]; vehicles: Vehicle[]; arrived: number; passed: number; remaining: number; maxQueue: number; meanDelay: number; capacity: number; overloaded: boolean; trace: {t:number;q:number}[] };
export function minuteCountdown(seconds: number) {
 if (!Number.isFinite(seconds)) return '時間未確認';
 const value=Math.max(0,Math.ceil(seconds)); return `${Math.floor(value/60)}分${String(value%60).padStart(2,'0')}秒`;
}
export function replayPhase(t:number, arrivals:number[], lead:number):'normal'|'prepare'|'closed' {
 if(arrivals.some(a=>t>=a-35&&t<a+10)) return 'closed';
 if(arrivals.some(a=>t>=a-35-lead&&t<a-35)) return 'prepare';
 return 'normal';
}
export function gateFraction(t:number, arrivals:number[]) {
 return Math.max(0,...arrivals.map(a=>t<a-35||t>=a+10?0:t<a-30?(t-(a-35))/5:t>=a+5?(a+10-t)/5:1));
}
export function vehicleStats(run:Pick<VehicleRun,'vehicles'|'params'>,time:number) {
 const t=Math.max(0,Math.min(time,run.params.horizon));
 const arrived=run.vehicles.filter(v=>v.arrival<=t);
 const waiting=arrived.filter(v=>v.entry===null||v.entry>t).length;
 const admitted=arrived.filter(v=>v.entry!==null&&v.entry<=t).length;
 const cleared=arrived.filter(v=>v.entry!==null&&v.entry+run.params.clearance<=t).length;
 const area=arrived.reduce((sum,v)=>sum+Math.max(0,Math.min(t,v.entry??t)-v.arrival),0);
 return {arrived:arrived.length,waiting,admitted,cleared,inCrossing:admitted-cleared,meanDelay:arrived.length?area/arrived.length:0};
}
export function simulateVehicles(p:VehicleParameters,policy:ComparisonPolicy,arrivals:number[]):VehicleRun {
 if([p.demand,p.stopHeadway,p.slowHeadway,p.dwell,p.clearance,p.margin,p.lead,p.horizon].some(v=>!Number.isFinite(v)||v<0)||arrivals.some(v=>!Number.isFinite(v))||p.stopHeadway<=0||p.slowHeadway<=0||p.horizon<1||p.horizon>3600||p.demand>2000||p.dwell>Math.min(p.stopHeadway,p.slowHeadway)) throw new Error('車両モデルの条件が不正です');
 arrivals=[...arrivals].sort((a,b)=>a-b);
 const intervals=arrivals.map(a=>[a-35-p.clearance-p.margin,a+10] as const).sort((a,b)=>a[0]-b[0]);
 const needsStop=(t:number)=>policy==='current'||p.fallback||!arrivals.some(a=>a+10>t)||(policy==='notice'&&replayPhase(t,arrivals,p.lead)==='prepare');
 const vehicles:Vehicle[]=[];let previous=-Infinity;
 for(let id=0;id<Math.floor(p.demand*p.horizon/3600+1e-8);id++) {
  const arrival=(id+1)*3600/p.demand;let entry=arrival;
  for(let i=0;i<100;i++) {
   const old=entry;const stop=needsStop(entry);
   entry=Math.max(entry,arrival+(stop?p.dwell:0),previous+(stop?p.stopHeadway:p.slowHeadway));
   const interval=intervals.find(([a,b])=>entry>=a&&entry<b);
   if(interval) entry=interval[1];
   if(Math.abs(old-entry)<1e-9) break;
   if(i===99) throw new Error('車両の進入時刻を確定できません');
  }
  const stopped=needsStop(entry)||entry>arrival+1e-7;
  const admitted=!p.blocked&&entry<p.horizon;
  vehicles.push({id,arrival,entry:admitted?entry:null,stopped});
  if(admitted) previous=entry;
 }
 const run={policy,params:p,arrivals,vehicles,arrived:0,passed:0,remaining:0,maxQueue:0,meanDelay:0,capacity:0,overloaded:false,trace:[] as {t:number;q:number}[]};
 const stats=vehicleStats(run,p.horizon);
 const changes=vehicles.flatMap(v=>v.entry===v.arrival?[]:[{t:v.arrival,n:1},...(v.entry===null?[]:[{t:v.entry,n:-1}])]).filter(e=>e.t<=p.horizon).sort((a,b)=>a.t-b.t||a.n-b.n);
 let q=0,maxQueue=0;for(const e of changes){q+=e.n;maxQueue=Math.max(maxQueue,q);}
 let capacity=0;
 for(let t=0;t<p.horizon;t+=.25) if(!p.blocked&&!intervals.some(([a,b])=>t>=a&&t<b)) capacity+=.25/(needsStop(t)?p.stopHeadway:p.slowHeadway);
 for(let t=0;t<=p.horizon;t+=10) run.trace.push({t,q:vehicleStats(run,t).waiting});
 return {...run,arrived:stats.arrived,passed:stats.cleared,remaining:stats.arrived-stats.cleared,maxQueue,meanDelay:stats.meanDelay,capacity:capacity/p.horizon*3600,overloaded:p.demand>=capacity/p.horizon*3600};
}
export function carPositions(run:VehicleRun,t:number) {
 const waiting=run.vehicles.filter(v=>v.arrival<=t&&(v.entry===null||v.entry>t));
 const crossing=run.vehicles.filter(v=>v.entry!==null&&t>=v.entry&&t<v.entry+run.params.clearance).map(v=>({id:v.id,y:350-(t-v.entry!)/run.params.clearance*250,moving:true}));
 const queue=waiting.slice(0,7).map((v,index)=>({id:v.id,y:350+index*43,moving:false}));
 const approach=run.vehicles.find(v=>v.arrival>t&&v.arrival-t<=5);
 if(approach&&waiting.length<7) queue.push({id:approach.id,y:350+waiting.length*43+(approach.arrival-t)*24,moving:true});
 return [...crossing,...queue];
}
