import { minuteCountdown } from './comparisonModel';
import type { VehicleRun } from './comparisonModel';
export type DiagramState = 'green'|'amber'|'red'|'gray';
export function comparisonState(run:VehicleRun,t:number):DiagramState {
 if(run.arrivals.some(a=>t>=a-35&&t<a+10)||run.params.blocked) return 'red';
 if(run.params.fallback||t>=run.params.horizon||!run.arrivals.some(a=>a+10>t)) return 'gray';
 if(run.arrivals.some(a=>t>=a-35-run.params.lead&&t<a-35)) return 'amber';
 return 'green';
}
export function sceneCountdown(run:VehicleRun,t:number,state:DiagramState) {
 const next=run.arrivals.find(a=>a+10>t);
 if(state==='gray'||next===undefined) return '時間表示停止';
 if(state==='red') return t<next?`列車到達まで ${minuteCountdown(next-t)}`:'列車通過中・開通時刻ではありません';
 return `警報開始まで ${minuteCountdown(next-35-t)}`;
}
