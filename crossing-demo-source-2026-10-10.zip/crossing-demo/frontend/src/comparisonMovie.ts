import { carPositions, gateFraction, vehicleStats } from './comparisonModel';
import type { VehicleRun } from './comparisonModel';
import { comparisonState, sceneCountdown } from './comparisonDisplay';
const colors={green:'#25a766',amber:'#e8b02e',red:'#df514e',gray:'#7c8d98'};
export function drawComparisonFrame(c:CanvasRenderingContext2D,left:VehicleRun,right:VehicleRun,t:number) {
 c.fillStyle='#f3f7fa';c.fillRect(0,0,1440,1080);c.font='bold 43px Meiryo, sans-serif';c.fillStyle='#183c4e';c.fillText('踏切の待ち車列を、同じ条件で比較',65,65);
 c.font='23px Meiryo, sans-serif';c.fillText(`再生時計 10:${String(Math.floor(t/60)).padStart(2,'0')}:${String(Math.floor(t%60)).padStart(2,'0')} / 駅ダイヤ抜粋＋道路条件の仮定`,65,109);
 [left,right].forEach((run,i)=>{
  const x=i?790:70;const proposed=run.policy==='notice';const state=comparisonState(run,t);const color=proposed?colors[state]:state==='red'?colors.red:'#497d9a';
  const label=state==='red'?'進入禁止':!proposed?'毎車 一時停止':state==='green'?'徐行（将来構想）':state==='amber'?'毎車 一時停止':'一時停止へ戻す';
  c.fillStyle='#183c4e';c.font='bold 29px Meiryo, sans-serif';c.fillText(proposed?'提案：予告＋徐行案':'従来：毎車一時停止',x,157);
  c.save();c.translate(x,185);c.beginPath();c.rect(0,0,560,650);c.clip();c.fillStyle='#e4eee7';c.fillRect(0,0,560,650);c.fillStyle='#637781';c.fillRect(208,0,146,650);
  c.strokeStyle='#edf2e7';c.lineWidth=3;c.setLineDash([13,11]);c.beginPath();c.moveTo(281,0);c.lineTo(281,650);c.stroke();c.setLineDash([]);
  c.fillStyle='#b5c3b7';c.fillRect(0,205,560,75);c.strokeStyle='#597075';c.lineWidth=4;[215,225,255,265].forEach(y=>{c.beginPath();c.moveTo(0,y);c.lineTo(560,y);c.stroke();});
  c.strokeStyle='#fff';c.lineWidth=5;c.beginPath();c.moveTo(214,325);c.lineTo(270,325);c.stroke();
  const gate=gateFraction(t,run.arrivals);[[196,305,1],[366,184,-1]].forEach(([gx,gy,side])=>{c.save();c.translate(gx,gy);c.rotate(-side*(1-gate)*88*Math.PI/180);c.lineWidth=8;c.strokeStyle='#263f4b';c.beginPath();c.moveTo(0,0);c.lineTo(side*85,0);c.stroke();c.lineWidth=5;c.strokeStyle='#f2cc62';c.setLineDash([12,10]);c.stroke();c.restore();});
  for(const a of run.arrivals.filter(a=>Math.abs(t-a)<5)) {c.fillStyle='#29799c';c.fillRect(218+(t-a)*100,223,124,34);c.fillStyle='#d5eef3';[-48,-24,0,24].forEach(wx=>c.fillRect(280+(t-a)*100+wx,227,16,10));}
  for(const car of carPositions(run,t)){c.fillStyle=proposed?'#239b84':'#cb6c5b';c.fillRect(229,car.y-19,24,38);c.strokeStyle='white';c.lineWidth=1;c.strokeRect(229,car.y-19,24,38);c.fillStyle='#cbe9ed';c.fillRect(233,car.y-11,16,9);}
  c.fillStyle='#112b36';c.fillRect(66,20,428,120);c.strokeStyle=color;c.lineWidth=7;c.strokeRect(66,20,428,120);c.fillStyle=color;c.font='bold 29px Meiryo, sans-serif';c.textAlign='center';c.fillText(label,280,75);c.fillStyle='white';c.font='20px Meiryo, sans-serif';c.fillText(sceneCountdown(run,t,state),280,111);c.textAlign='left';
  c.restore();const stats=vehicleStats(run,t);c.fillStyle='#183c4e';c.font='bold 27px Meiryo, sans-serif';c.fillText(`待ち ${stats.waiting}台 / 通過済 ${stats.cleared}台`,x,883);c.font='23px Meiryo, sans-serif';c.fillText(`期間内平均遅れ ${stats.meanDelay.toFixed(1)}秒/台`,x,925);
 });
 const before=vehicleStats(left,t),after=vehicleStats(right,t);c.fillStyle='#177b80';c.font='bold 29px Meiryo, sans-serif';c.fillText(`待ち台数の差 ${before.waiting-after.waiting}台 / 通過済みの差 ${after.cleared-before.cleared}台`,65,989);
 c.fillStyle='#58727e';c.font='20px Meiryo, sans-serif';c.fillText(`片方向${left.params.demand}台/時・黄は警報${left.params.lead}秒前・停止1秒・車頭時間5秒→3秒・早送り`,65,1030);c.fillText('机上検証用。現地効果・安全性は未検証。実設備は未接続。車の位置は模式図です。',65,1064);
}
export async function exportComparisonMovie(left:VehicleRun,right:VehicleRun,progress:(n:number)=>void) {
 if(typeof MediaRecorder==='undefined') throw new Error('このブラウザは動画出力に対応していません');
 const canvas=document.createElement('canvas');canvas.width=1440;canvas.height=1080;const ctx=canvas.getContext('2d');if(!ctx)throw new Error('描画を開始できません');
 const formats=['video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'];const mimeType=formats.find(f=>MediaRecorder.isTypeSupported(f));if(!mimeType)throw new Error('WebM録画に対応していません');
 const target=right.arrivals.find(a=>a>=150&&a<3000)??210;const start=Math.max(0,target-150),end=Math.min(right.params.horizon,target+360);const length=30000;
 drawComparisonFrame(ctx,left,right,start);const stream=canvas.captureStream(20);const recorder=new MediaRecorder(stream,{mimeType,videoBitsPerSecond:2400000});const chunks:Blob[]=[];
 recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};
 await new Promise<void>((resolve,reject)=>{
  const began=performance.now();
  const timer=window.setInterval(()=>{const ratio=Math.min(1,(performance.now()-began)/length);drawComparisonFrame(ctx,left,right,start+(end-start)*ratio);progress(Math.floor(ratio*100));if(ratio>=1&&recorder.state==='recording')recorder.stop();},50);
  const watchdog=window.setTimeout(()=>{if(recorder.state==='recording')recorder.stop();},45000);
  const cleanup=()=>{window.clearInterval(timer);window.clearTimeout(watchdog);stream.getTracks().forEach(track=>track.stop());};
  recorder.onerror=()=>{cleanup();reject(new Error('録画に失敗しました'));};
  recorder.onstop=()=>{cleanup();const blob=new Blob(chunks,{type:mimeType});if(!blob.size){reject(new Error('動画を保存できません'));return;}const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='crossing-comparison.webm';a.click();window.setTimeout(()=>URL.revokeObjectURL(url),60000);progress(100);resolve();};
  try { recorder.start(1000); } catch { cleanup(); reject(new Error('録画を開始できません')); }
 });
}
