import { useMemo, useState } from 'react';
import { defaults, simulate } from './proposalModel';
import { slowImage } from './conceptAssets';
import './Overview.css';
type Target = 'experience' | 'proposal' | 'evidence' | 'deployment';
const presets = [
  { label: '交通量が多い例', demand: 600, slowHeadway: 3, explanation: '停止による処理の遅さがボトルネックになる条件。' },
  { label: '交通量が少ない例', demand: 300, slowHeadway: 3, explanation: '車列がたまりにくく、改善する時間も小さくなります。' },
  { label: '徐行でも進みが遅い例', demand: 600, slowHeadway: 5, explanation: '1台の通過間隔が変わらなければ、停止を徐行に替えても改善しません。' },
];
const fmt = (n: number) => n.toLocaleString('ja-JP', { maximumFractionDigits: 1 });
export default function Overview({ navigate }: { navigate: (view: Target) => void }) {
  const [selected, setSelected] = useState(0);
  const p = { ...defaults, demand: presets[selected].demand, slowHeadway: presets[selected].slowHeadway };
  const results = useMemo(() => [simulate({ ...defaults, demand: presets[selected].demand, slowHeadway: presets[selected].slowHeadway }, 'current'), simulate({ ...defaults, demand: presets[selected].demand, slowHeadway: presets[selected].slowHeadway }, 'notice')], [selected]);
  const [before, after] = results;
  const saving = before.meanDelay - after.meanDelay;
  const largest = Math.max(1, before.meanDelay, after.meanDelay);
  return <div className="overviewPage" id="top">
    <section className="overviewHero"><div><span className="kicker">踏切みまもり / 社会実装を考えるPoC</span><h1>列車の接近を知らせて、<br />踏切の待ち時間を減らせるか。</h1><p>踏切の上に、色・文字・予測時間で伝える表示器を。実ダイヤの再生と交通モデルで、効果と実用化の条件を見える形にしました。</p><div className="overviewActions"><button onClick={() => navigate('experience')}>動く表示を体験する →</button><button onClick={() => navigate('deployment')}>費用・期間・許可を見る</button></div></div><figure><img src={slowImage} alt="踏切の上部に予告表示器を設置する将来構想" /><figcaption>AI生成の設置構想。緑の徐行表示は将来の制度検討案です。</figcaption></figure></section>
    <div className="overviewNotice"><b>現在の公道では一時停止義務に従います。</b>このWebアプリは提案と机上検証用です。時刻表だけで通行を許可する設備ではありません。</div>
    <section className="overviewEffect"><div className="overviewSectionHead"><div><span className="kicker">効果を30秒で理解する</span><h2>どの条件なら、どれだけ変わる？</h2></div><span className="assumptionTag">現地の実測結果ではなく、仮定による試算</span></div><div className="presetButtons">{presets.map((preset, i) => <button key={preset.label} aria-pressed={selected === i} onClick={() => setSelected(i)}>{preset.label}</button>)}</div><p>{presets[selected].explanation}</p><div className="effectComparison"><div className="effectBars">{results.map((r,i) => <div key={r.policy}><div className="effectBarLabel"><b>{i ? '予告＋条件付き徐行案' : '現行の毎車一時停止'}</b><strong>{fmt(r.meanDelay)}秒 / 台</strong></div><div className="effectTrack"><div style={{ width: `${r.meanDelay / largest * 100}%`, background: i ? '#157c85' : '#d96555' }} /></div></div>)}</div><div className="savingCard"><span>期間内平均遅れの差</span><strong>{fmt(Math.abs(saving))}<small>秒 / 台{saving < 0 ? '増加' : '短縮'}</small></strong><p>{saving === 0 ? 'この条件では改善なし' : `${fmt(Math.abs(saving / before.meanDelay * 100))}% ${saving < 0 ? '増加' : '削減'}（机上値）`}</p></div></div><div className="effectQueue">{results.map((r,i) => <div key={r.policy}><span>{i ? '提案案' : '現行'}の最大車列</span><div className="carLine" aria-hidden="true">{Array.from({ length: Math.min(24, Math.ceil(r.maxQueue)) }, (_,n) => <i key={n} />)}</div><b>{fmt(r.maxQueue)}台</b></div>)}</div><p className="finePrint">条件：片方向 {p.demand}台/時、停止5秒/台、徐行{p.slowHeadway}秒/台。4分ごとに45秒遮断、遮断前30秒は停止。60分・初期車列ゼロ・一定流入。車列は流体近似のため小数です。列車の遮断待ちは残り、終了時に残る車の将来の遅れは含みません。交通量・車頭時間・安全性は未測定です。</p><button className="overviewTextButton" onClick={() => navigate('proposal')}>条件を自分で変えて詳しく計算する →</button></section>
    <section className="overviewSteps"><div><b>01</b><h3>まず測る</h3><p>交通量・停止と徐行の通過間隔・警報時間を測り、効果のある候補地を選びます。</p></div><div><b>02</b><h3>設備情報で確かめる</h3><p>全列車の接近と警報・遮断・出口を確認。時刻表だけで判断する方式から進めます。</p></div><div><b>03</b><h3>関係者と実証する</h3><p>市・道路管理者、警察、鉄道事業者に、監視のみの検証から相談します。</p></div></section><div className="overviewActions"><button onClick={() => navigate('deployment')}>実用化への具体的な計画 →</button><button onClick={() => navigate('evidence')}>設置画像・出典・相談先 →</button></div>
  </div>;
}

