import { useMemo, useState } from 'react';
import { assessSafety, defaults, policyNames, safetyDefaults, simulate } from './proposalModel';
import type { Parameters, Policy, SafetyInput } from './proposalModel';

const policies: Policy[] = ['current', 'notice', 'signal'];
const colors = ['#db3341', '#165dcc', '#09a66d'];
const fmt = (v: number) => v.toLocaleString('ja-JP', { maximumFractionDigits: 1 });
const controls: { key: keyof Parameters; label: string; min: number; max: number; step: number; unit: string }[] = [
  { key: 'demand', label: '片方向の交通需要', min: 0, max: 1600, step: 50, unit: '台/時' },
  { key: 'stopHeadway', label: '一時停止時の通過車頭時間', min: 2, max: 10, step: .5, unit: '秒/台' },
  { key: 'slowHeadway', label: '徐行・信号時の通過車頭時間', min: 2, max: 10, step: .5, unit: '秒/台' },
  { key: 'cycle', label: '列車による遮断周期', min: 180, max: 600, step: 30, unit: '秒' },
  { key: 'closure', label: '警報〜再開の進入禁止時間', min: 15, max: 90, step: 5, unit: '秒/周期' },
  { key: 'lead', label: '警報開始前の一時停止期間', min: 0, max: 60, step: 5, unit: '秒' },
];
export default function Proposal() {
  const [p, setP] = useState<Parameters>(defaults);
  const [s, setS] = useState<SafetyInput>(safetyDefaults);
  const [scenario, setScenario] = useState('通常');
  const results = useMemo(() => policies.map(policy => simulate(p, policy)), [p]);
  const safety = assessSafety(s, p.lead);
  const ymax = Math.max(10, ...results.map(r => r.maxQueue));
  const reduction = results[0].meanDelay > 0 ? 100 * (1 - results[1].meanDelay / results[0].meanDelay) : null;
  const setSafetyScenario = (name: string, patch: Partial<SafetyInput>) => { setScenario(name); setS({ ...safetyDefaults, ...patch }); };
  const download = () => {
    const report = { title: '踏切の予告情報と交通制御の比較PoC', exportedAt: new Date().toISOString(), modelVersion: 'fluid-queue-1', assumptions: p, safetyInput: s, safetyDecision: safety, results, limitations: ['架空の一定需要・周期・車頭時間。実測値ではない', '片方向・単一踏切・初期車列ゼロ・事故リスク未推定', '平均遅れは観測期間内の車列積分／全到着台数。終了時未通過車の将来遅れを含まない', '公道の通行許可を出すシステムではない'] };
    const url = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a'); a.href = url; a.download = 'crossing-poc-report.json'; a.click(); URL.revokeObjectURL(url);
  };
  return <div className="adminPage proposalPage">
    <div className="adminHeading"><div><span className="sectionLabel">POLICY & SAFETY LAB</span><h1>一時停止を、検証する。</h1><p>交通効果・安全条件・制度への道筋を同じ画面で説明するPoC</p></div><button className="primaryButton" onClick={download}>条件と結果を保存</button></div>
    <div className="sourceNotice"><b>全数値は仮定値によるシミュレーション</b><span>API不要・実設備未接続・通行許可機能なし</span></div>
    <section className="card legalCard"><h2>法改正の前に、既存制度を比較対象へ</h2><p>道路交通法33条1項には、信号機の信号に従う場合の一時停止の例外があります。予告表示そのものはこの例外を成立させません。まず踏切信号機との連携可能性を管理者と検討し、必要な制度変更を具体化します。</p><a href="https://laws.e-gov.go.jp/law/335AC0000000105" target="_blank" rel="noreferrer">道路交通法33条</a> ・ <a href="https://www.ktr.mlit.go.jp/ktr_content/content/000907748.pdf" target="_blank" rel="noreferrer">国土交通省・踏切信号機の説明資料</a><small>法令・資料確認：2026年10月10日。信号機案の採用条件・設計は関係機関との確認が必要。</small></section>
    <section className="adminGrid">
      <article className="card"><span className="sectionLabel">ASSUMPTIONS</span><h2>比較条件を変える</h2><p>同じ到着交通と遮断時間で3案を比較。遮断中はすべて進入禁止です。</p>
        <div className="presetRow"><button onClick={() => setP(defaults)}>標準</button><button onClick={() => setP({ ...defaults, demand: 300 })}>低需要</button><button onClick={() => setP({ ...defaults, demand: 1200 })}>過飽和</button><button onClick={() => setP({ ...defaults, slowHeadway: 5 })}>徐行による容量増なし</button></div>
        {controls.map(c => <label className="rangeControl" key={c.key}><span>{c.label}<b>{fmt(p[c.key])} {c.unit}</b></span><input type="range" min={c.min} max={c.max} step={c.step} value={p[c.key]} onChange={e => setP({ ...p, [c.key]: Number(e.target.value) })} /></label>)}
        <p className="finePrint">車頭時間は連続する車両の通過間隔です。停止時間だけでなく、発進・確認・車種の影響を含む仮定。評価期間60分、初期車列ゼロ、一定流入、片方向のモデルです。</p>
      </article>
      <article className="card"><span className="sectionLabel">COMPARISON</span><h2>効果が出る条件・出ない条件</h2><div className="effectValue">{reduction === null ? '—' : fmt(reduction)}<small>%</small></div><p>予告＋徐行案の期間内平均遅れの削減率</p><p className="finePrint">現地の改善率ではありません。徐行時の車頭時間を短く仮定したことが容量増の主要因です。遮断の多い踏切や出口渋滞では効果が制約されます。</p>
        <div className="tableScroll"><table className="comparisonTable"><thead><tr><th>方式</th><th>平均遅れ</th><th>最大車列</th><th>残留車列</th></tr></thead><tbody>{results.map(r => <tr key={r.policy}><th>{policyNames[r.policy]}</th><td>{fmt(r.meanDelay)}秒</td><td>{fmt(r.maxQueue)}台</td><td>{fmt(r.remaining)}台</td></tr>)}</tbody></table></div>
        {results.map(r => <p className="capacityLine" key={r.policy}>{policyNames[r.policy]}：平均容量 {fmt(r.capacity)}台/時 <b className={r.overloaded ? 'danger' : 'ok'}>{r.overloaded ? '需要が容量以上' : '需要は容量未満'}</b></p>)}
        <p className="finePrint">平均遅れ＝期間内の車列面積÷全到着台数。終了時に残る車の将来遅れは含みません。残留車列がある場合は長期定常の値として使えません。小数台は流体近似です。</p>
      </article>
    </section>
    <section className="card chartCard"><h2>車列の推移 · 60分</h2><svg viewBox="0 0 1000 240" role="img" aria-label="3方式の待ち車列の時系列比較"><text x="5" y="18">{fmt(ymax)}台</text><text x="15" y="208">0</text><path d="M60 20 V200 H980" fill="none" stroke="#bac5d6" />{results.map((r, i) => <polyline key={r.policy} fill="none" stroke={colors[i]} strokeWidth="2.5" points={r.trace.map(v => `${60 + v.t / p.horizon * 920},${200 - v.q / ymax * 170}`).join(' ')} />)}{[0, 15, 30, 45, 60].map(t => <text key={t} x={60 + t / 60 * 920} y="226" textAnchor="middle">{t}分</text>)}</svg><div className="chartLegend">{policies.map((policy, i) => <span key={policy}><i style={{ background: colors[i] }} />{policyNames[policy]}</span>)}</div></section>
    <section className="card chartCard"><h2>予告停止期間の感度分析</h2><p>「30秒」を固定の正解とせず、交通効果の変化を比較します。安全上必要な時間は別途決めます。</p><div className="sensitivityGrid">{[0, 15, 30, 45, 60].map(lead => { const r = simulate({ ...p, lead }, 'notice'); return <div key={lead}><span>警報開始の{lead}秒前</span><strong>{fmt(r.meanDelay)}秒</strong><small>期間内平均遅れ</small></div>; })}</div></section>
    <section className="adminGrid safetyLab">
      <article className="card"><span className="sectionLabel">FAIL-SAFE LAB</span><h2>予測だけで進入を許可しない</h2><p>異常を注入すると、理由付きで候補判定を取り消します。これは机上の判定ロジックで、安全認証済みの制御ではありません。</p><div className="presetRow">{[
        ['通常', {}], ['通信途絶', { connected: false }], ['情報の陳腐化', { age: 4 }], ['センサー故障', { sensor: false }], ['警報作動', { alarm: true }], ['遮断機閉', { gateOpen: false }], ['出口渋滞', { exitClear: false }], ['障害物', { obstacle: true }], ['復旧未確認', { recovered: false }], ['予測が早まる', { secondsToWarning: 25 }],
      ].map(([name, patch]) => <button className={scenario === name ? 'selected' : ''} key={String(name)} onClick={() => setSafetyScenario(String(name), patch as Partial<SafetyInput>)}>{String(name)}</button>)}</div>
        <label className="rangeControl"><span>警報開始までの予測<b>{s.secondsToWarning}秒</b></span><input type="range" min="0" max="120" value={s.secondsToWarning} onChange={e => setS({ ...s, secondsToWarning: Number(e.target.value) })} /></label>
        <label className="rangeControl"><span>早着側の予測誤差<b>{s.uncertainty}秒</b></span><input type="range" min="0" max="45" value={s.uncertainty} onChange={e => setS({ ...s, uncertainty: Number(e.target.value) })} /></label>
        <p className="finePrint">クリアランス12秒＋余裕8秒は説明用仮定。車長・踏切長・勾配・低速車・歩行者等の条件に基づく実測と設計が必要です。</p>
      </article>
      <article className={`card decisionCard ${safety.eligible ? '' : 'blocked'}`} aria-live="polite"><span className="sectionLabel">DECISION TRACE</span><h2>{safety.eligible ? '制度・設備の検討候補' : '進入許可の候補から除外'}</h2><p>{safety.eligible ? '机上条件がそろっています。公道では現行の一時停止義務・現地信号に従います。' : '候補判定を取り消し、現地規制に従う状態へ。踏切内にいる車に停止を指示するものではありません。'}</p><code>予告閾値 = max({p.lead}, {s.uncertainty} + {s.clearance} + {s.margin}) = {safety.threshold}秒</code><ul>{safety.reasons.length ? safety.reasons.map(r => <li key={r}>{r}</li>) : <li>通信・設備・出口空間・復旧確認・時間余裕の机上条件成立</li>}</ul><p className="finePrint">閾値と等しい場合も許可候補を取り消します。一般公開の列車位置APIは安全保証の根拠にはできません。復旧時の再確認と独立した既存保安装置が必要です。</p></article>
    </section>
    <section className="card roadmap"><h2>提案から実証まで</h2><ol><li><strong>現状を測る</strong><p>方向別交通量、車頭時間、実遮断時間、出口渋滞、歩行者・大型車、近接交差点を観測しモデルを較正。</p></li><li><strong>机上・閉鎖環境で比較</strong><p>予告表示が急加速や判断ミスを誘発しないか確認。故障・遅延・早着・複数列車・再起動を試験。</p></li><li><strong>自治体・警察・鉄道・道路管理者と協議</strong><p>既存の踏切信号機制度で実現できる範囲、設備連動、管理責任、費用、実証の条件を整理。</p></li><li><strong>監視だけの実地評価から始める</strong><p>通行ルールを変えず予測誤差と故障を測定。安全条件と評価計画の合意後に、必要な制度変更を提案。</p></li></ol></section>
    <section className="safetyNotice"><strong>このPoCの範囲</strong><p>交通モデルと異常判定は独立した机上実験です。事故リスク・実装費用・現地削減率は未検証。カウントダウンは説明用で、運転者に対する通行指示ではありません。</p></section>
  </div>;
}
