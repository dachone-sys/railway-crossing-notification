import { carPositions, gateFraction, vehicleStats } from './comparisonModel';
import type { VehicleRun } from './comparisonModel';
import { comparisonState, sceneCountdown } from './comparisonDisplay';
const colors={green:'#25a766',amber:'#e8b02e',red:'#df514e',gray:'#7c8d98'};
export default function ComparisonScene({run,t}:{run:VehicleRun;t:number}) {
 const state=comparisonState(run,t);const proposed=run.policy==='notice';const fraction=gateFraction(t,run.arrivals);const cars=carPositions(run,t);const stats=vehicleStats(run,t);
 const label=state==='red'?'進入禁止':!proposed?'毎車 一時停止':state==='green'?'徐行（将来構想）':state==='amber'?'毎車 一時停止':'一時停止へ戻す';
 const color=proposed?colors[state]:state==='red'?colors.red:'#497d9a';
 return <svg className="comparisonDiagram" viewBox="0 0 560 650" role="img" aria-label={`${proposed?'提案案':'従来案'}。${label}。待ち${stats.waiting}台、通過済み${stats.cleared}台。`}>
 <rect width="560" height="650" rx="12" fill="#e5eee8"/><rect x="208" width="146" height="650" fill="#657982"/><path d="M281 0V190 M281 276V650" stroke="#e5ebdf" strokeWidth="3" strokeDasharray="13 11"/>
 <rect y="205" width="560" height="75" fill="#bbc6bb"/>{[220,260].map(y=><g key={y}><path d={`M0 ${y-5}H560 M0 ${y+5}H560`} stroke="#586f73" strokeWidth="4"/>{Array.from({length:25},(_,i)=><path key={i} d={`M${i*24} ${y-12}V${y+12}`} stroke="#8a9289" strokeWidth="5"/>)}</g>)}
 <path d="M214 325H270" stroke="white" strokeWidth="5"/>
 <g transform="translate(196 305)"><circle r="10" fill="#314d59"/><g transform={`rotate(${-88*(1-fraction)})`}><path d="M0 0H85" stroke="#263f4b" strokeWidth="8"/><path d="M0 0H85" stroke="#f3cd62" strokeWidth="5" strokeDasharray="12 10"/></g></g>
 <g transform="translate(366 184)"><circle r="10" fill="#314d59"/><g transform={`rotate(${88*(1-fraction)})`}><path d="M0 0H-85" stroke="#263f4b" strokeWidth="8"/><path d="M0 0H-85" stroke="#f3cd62" strokeWidth="5" strokeDasharray="12 10"/></g></g>
 <circle cx="176" cy="292" r="7" fill={state==='red'&&fraction>0?'#e95b54':'#869ca3'}/>
 {run.arrivals.filter(a=>Math.abs(t-a)<5).map((a,i)=><g key={i} transform={`translate(${280+(t-a)*100},240)`}><rect x="-62" y="-16" width="124" height="32" rx="8" fill="#2b779a"/>{[-48,-24,0,24].map(x=><rect key={x} x={x} y="-10" width="16" height="10" fill="#cbe9f2"/>)}<path d="M-62 8H62" stroke="#f7cd61" strokeWidth="4"/></g>)}
 {cars.map(car=><g key={car.id} transform={`translate(241 ${car.y})`}><rect x="-12" y="-19" width="24" height="38" rx="6" fill={proposed?'#239b84':'#cb6c5b'} stroke="#fff" strokeWidth="1.5"/><rect x="-8" y="-11" width="16" height="9" rx="2" fill="#d1edf1"/><rect x="-7" y="9" width="14" height="4" fill="#aed7df"/></g>)}
 <path d="M90 122V24H470V122" fill="none" stroke="#778e98" strokeWidth="9"/>
 <rect x="75" y="24" width="410" height="114" rx="6" fill="#102a34" stroke={color} strokeWidth="7"/>
 <text x="280" y="48" textAnchor="middle" fill="#c5d9e0" fontSize="14">説明用・現地の通行指示ではありません</text><text x="280" y="83" textAnchor="middle" fill={color} fontSize="27" fontWeight="bold">{label}</text><text x="280" y="114" textAnchor="middle" fill="white" fontSize="19">{sceneCountdown(run,t,state)}</text>
 <rect x="17" y="398" width="175" height="147" rx="9" fill="white"/><text x="31" y="427" fontSize="17" fill="#244754">現在待ち {stats.waiting}台</text><text x="31" y="455" fontSize="17" fill="#244754">通過済 {stats.cleared}台</text><text x="31" y="483" fontSize="17" fill="#244754">通過中 {stats.inCrossing}台</text><text x="31" y="518" fontSize="13" fill="#5b747f">最大7台を描画</text>
 <rect x="16" y="602" width="528" height="34" rx="7" fill="white"/><text x="280" y="625" textAnchor="middle" fill="#345661" fontSize="17">{state==='red'?'両案とも停止・遮断機の動きは共通':run.policy==='current'||state==='amber'||state==='gray'?'停止線で一旦止まり、退出余裕を確認':'車列がなければ止まらず低速で通過する想定'}</text>
 </svg>;
}
