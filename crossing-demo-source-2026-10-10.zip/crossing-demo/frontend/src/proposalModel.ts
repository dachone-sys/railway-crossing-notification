/** Educational fluid queue model; no connection to railway safety equipment. */
export type Parameters = {
  demand: number; stopHeadway: number; slowHeadway: number; cycle: number;
  closure: number; lead: number; horizon: number;
};
export const defaults: Parameters = { demand: 600, stopHeadway: 5, slowHeadway: 3, cycle: 240, closure: 45, lead: 30, horizon: 3600 };
export type Policy = 'current' | 'notice' | 'signal';
export const policyNames: Record<Policy, string> = {
  current: '現行・毎車一時停止', notice: '予告＋条件付き徐行（制度検討）', signal: '踏切信号機連携（既存制度）',
};
export type Result = {
  policy: Policy; arrived: number; passed: number; remaining: number; maxQueue: number;
  meanDelay: number; capacity: number; overloaded: boolean; trace: { t: number; q: number }[];
};
export function simulate(p: Parameters, policy: Policy, arrivals?: number[]): Result {
  if (Object.values(p).some(v => !Number.isFinite(v) || v < 0) || p.cycle <= p.closure || p.stopHeadway <= 0 || p.slowHeadway <= 0 || p.horizon < 1 || p.horizon > 86400 || p.lead + p.closure > p.cycle) throw new Error('入力条件を確認してください');
  const lambda = p.demand / 3600;
  if (arrivals?.some(v => !Number.isFinite(v))) throw new Error('列車時刻が不正です');
  let q = 0, passed = 0, area = 0, maxQueue = 0;
  let integratedCapacity = 0;
  const trace: Result['trace'] = [{ t: 0, q: 0 }];
  const dt = 0.25;
  for (let t = 0; t < p.horizon; t += dt) {
    const step = Math.min(dt, p.horizon - t);
    const phase = (t + step / 2) % p.cycle;
    const sampleTime = t + step / 2;
    const closed = arrivals ? arrivals.some(a => sampleTime >= a - (p.closure - 10) && sampleTime < a + 10) : phase >= p.cycle - p.closure;
    const prepare = arrivals ? arrivals.some(a => sampleTime >= a - (p.closure - 10) - p.lead && sampleTime < a - (p.closure - 10)) : phase >= p.cycle - p.closure - p.lead;
    // Notice policy keeps mandatory stops in the pre-warning window.
    const headway = policy === 'current' || (policy === 'notice' && prepare) ? p.stopHeadway : p.slowHeadway;
    const mu = closed ? 0 : 1 / headway;
    integratedCapacity += mu * step;
    const prev = q;
    const served = Math.min(q + lambda * step, mu * step);
    q = Math.max(0, q + lambda * step - served);
    passed += served;
    // Exact integral for constant fluid rates, including queue dissipation.
    const drain = mu - lambda;
    area += drain > 0 && prev > 0 && q === 0 ? prev * (prev / drain) / 2 : (prev + q) * step / 2;
    maxQueue = Math.max(maxQueue, q);
    if (Math.round((t + step) * 4) % 40 === 0 || t + step === p.horizon) trace.push({ t: t + step, q });
  }
  const open = p.cycle - p.closure;
  const capacity = arrivals ? integratedCapacity / p.horizon * 3600 : 3600 / p.cycle * (policy === 'current' ? open / p.stopHeadway : policy === 'notice' ? (open - p.lead) / p.slowHeadway + p.lead / p.stopHeadway : open / p.slowHeadway);
  const arrived = lambda * p.horizon;
  return { policy, arrived, passed, remaining: q, maxQueue, meanDelay: arrived ? area / arrived : 0, capacity, overloaded: p.demand >= capacity, trace };
}
export type SafetyInput = {
  secondsToWarning: number; uncertainty: number; clearance: number; margin: number;
  age: number; connected: boolean; sensor: boolean; gateOpen: boolean; alarm: boolean;
  exitClear: boolean; obstacle: boolean; recovered: boolean;
};
export const safetyDefaults: SafetyInput = {
  secondsToWarning: 90, uncertainty: 10, clearance: 12, margin: 8, age: 0,
  connected: true, sensor: true, gateOpen: true, alarm: false, exitClear: true, obstacle: false, recovered: true,
};
export function assessSafety(s: SafetyInput, lead: number) {
  const reasons: string[] = [];
  if ([s.secondsToWarning, s.uncertainty, s.clearance, s.margin, s.age, lead].some(v => !Number.isFinite(v) || v < 0)) reasons.push('時間入力が不正または不明');
  if (!s.connected || s.age > 3) reasons.push('通信断または情報が3秒超更新されていない');
  if (!s.sensor) reasons.push('センサー異常');
  if (!s.gateOpen || s.alarm) reasons.push('遮断機が開いていない／警報作動');
  if (!s.exitClear) reasons.push('出口側に車両を収容する空間がない');
  if (s.obstacle) reasons.push('踏切内の障害物');
  if (!s.recovered) reasons.push('復旧確認が未完了');
  const threshold = Math.max(lead, s.uncertainty + s.clearance + s.margin);
  if (s.secondsToWarning <= threshold) reasons.push(`予告停止領域（警報開始まで${threshold}秒以下）`);
  return { eligible: reasons.length === 0, threshold, reasons };
}
