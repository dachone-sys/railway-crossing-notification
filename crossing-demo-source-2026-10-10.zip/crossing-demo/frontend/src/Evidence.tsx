import { useMemo, useState } from 'react';
import { defaults, policyNames, simulate } from './proposalModel';
import type { Policy } from './proposalModel';
import './Evidence.css';

const policies: Policy[] = ['current', 'notice', 'signal'];
const fmt = (n: number) => n.toLocaleString('ja-JP', { maximumFractionDigits: 1 });
const base = import.meta.env.BASE_URL;
const slowImage = `${base}images/踏切デバイス_徐行と予測時間.png`;
const installationImage = `${base}images/踏切デバイス_設置イメージ.png`;
const observationTemplate = `${base}data/field-observation-template.csv`;
const sources = [
  ['黒沢踏切の整備効果（国土交通省）', 'https://www.mlit.go.jp/road/sisaku/fumikiri/pdf/jirei_03.pdf'],
  ['車頭時間・交通容量の考え方（FHWA、2008年版）', 'https://ops.fhwa.dot.gov/publications/fhwahop08024/chapter3.htm'],
  ['道路標識の設置方法（国土交通省）', 'https://www.mlit.go.jp/road/sign/annai/setting02.htm'],
  ['県道の相談先：厚木土木事務所東部センター', 'https://www.pref.kanagawa.jp/div/1918/index.html'],
  ['信号機の相談先：神奈川県警察', 'https://www.police.pref.kanagawa.jp/kotsu/kotsu_iken/mesf1017.html'],
  ['道路交通法 第33条', 'https://laws.e-gov.go.jp/law/335AC0000000105'],
];
export default function Evidence() {
  const [seconds, setSeconds] = useState(90);
  const [lost, setLost] = useState(false);
  const [demand, setDemand] = useState(600);
  const [headway, setHeadway] = useState(3);
  const [length, setLength] = useState(30);
  const [slow, setSlow] = useState(10);
  const [speed, setSpeed] = useState(40);
  const p = { ...defaults, demand, slowHeadway: headway };
  const results = useMemo(() => policies.map(policy => simulate({ ...defaults, demand, slowHeadway: headway }, policy)), [demand, headway]);
  const directDelay = 3.6 * length * (1 / slow - 1 / speed);
  const state = lost ? 'lost' : seconds <= 35 ? 'closed' : seconds <= 65 ? 'prepare' : 'slow';
  const title = { lost: '情報停止', closed: '進入禁止', prepare: '一時停止', slow: '徐行' }[state];
  const save = () => {
    const report = { model: 'fluid-queue-1', checkedOn: '2026-10-10', provenance: { trafficDemand: '仮定・現地未測定', headways: '仮定・現地未測定', trainSchedule: 'この画面は周期の仮定。実ダイヤは体験画面へ', empiricalCase: '黒沢踏切の他地点・信号化実績。今回の装置の効果ではない' }, parameters: p, directSlowDelay: { length, slowKph: slow, referenceKph: speed, seconds: directDelay }, results, sources, limitations: ['単一・片方向・一定流入・初期車列0', '平均遅れは期間内の車列積分/全到着台数', '未通過車の期間後の遅れ、個別の減速発進損失、出口交差点を含まない', '現地改善率・安全性は未検証'] };
    const url = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a'); a.href = url; a.download = 'crossing-evidence-report.json'; a.click(); URL.revokeObjectURL(url);
  };
  return <div className="adminPage evidencePage">
    <div className="adminHeading"><div><span className="sectionLabel">DESIGN & EVIDENCE</span><h1>見える提案。説明できる効果。</h1><p>設置イメージ、計算の根拠、実績、相談先を一つに。</p></div><button onClick={save} className="primaryButton">条件・出典・結果を保存</button></div>
    <div className="sourceNotice"><b>制度変更後の構想を可視化</b><span>現地データ未取得・写真はAI生成・時刻は例示</span></div>
    <section className="card designIntro"><h2>色と文字で、状態をすぐに理解する</h2><p>緑＝徐行、黄橙＝一時停止、赤＝進入禁止、灰＝情報停止の提案。色だけに頼らず、必ず行動を文字で示します。法定信号との混同や、カウントダウンによる急加速は検証項目です。</p>
      <div className="deviceDemo"><div className={`deviceDisplay ${state}`} role="status"><small>将来構想 / 表示デモ</small><strong>{title}</strong><span>{lost ? '現地に従う' : state === 'closed' ? '警報・遮断の想定期間' : '列車到来まで（予測）'}</span><b>{lost || state === 'closed' ? '時間表示なし' : `約 ${seconds} 秒`}</b><small>{!lost && state !== 'closed' ? `予測幅 ${Math.max(0, seconds - 15)}～${seconds + 15}秒` : '時計だけで通行を判断しない'}</small></div>
      <div><label className="rangeControl"><span>列車到来までの例示時間<b>{seconds}秒</b></span><input aria-label="例示時間" type="range" min="0" max="180" value={seconds} onChange={e => setSeconds(Number(e.target.value))} /></label><div className="presetRow"><button onClick={() => { setLost(false); setSeconds(90); }}>緑・徐行</button><button onClick={() => { setLost(false); setSeconds(55); }}>黄橙・一時停止</button><button onClick={() => { setLost(false); setSeconds(20); }}>赤・進入禁止</button><button onClick={() => setLost(true)}>灰・情報停止</button></div><p className="finePrint">例：到来35秒前に警報、その30秒前から一時停止を仮定。±15秒は例示。カウントダウンが警報開始までの時間とは異なることを表示します。</p><p><b>現在の公道では一時停止義務と現地信号に従います。</b>この表示だけで停止を免除できません。</p></div></div>
      <figure><img src={slowImage} alt="制度変更後の構想：左側の専用支柱に緑の徐行表示と予想到来時間を示すAI生成写真" /><figcaption>AI生成の架空の設置構想。緑は提案上の状態色で、実際の通行許可ではありません。</figcaption></figure>
    </section>
    <section className="card"><h2>各進入方向に、予告・確認・出口検知</h2><div className="placementGrid"><article><b>A / 手前の予告</b><p>停止線の60～100m手前を候補に。40km/hなら4秒で約44m進むため、読む時間と減速の余裕を実測します。</p></article><article><b>B / 停止位置で確認</b><p>停止線の10～20m手前を候補に。左側の専用支柱で、待機車と大型車の両方から読める向きを検討します。</p></article><article><b>C / 出口の検知</b><p>踏切を出た先の退避余地をレーダー等で把握。既存の警報機や歩道の通行空間を妨げない配置にします。</p></article></div><p className="finePrint">距離・高さは現地未確認の候補値。写真は寸法の根拠ではありません。歩道の建築限界や車道上の高さは道路管理者と確認します。</p><figure><img loading="lazy" src={installationImage} alt="昼間の予告、踏切直前の確認、雨天夜間の視認性を比較した3枚のAI生成写真" /><figcaption>昼間・踏切直前・雨天夜間の設置イメージ。文字高、輝度、遮蔽は実寸試験で評価。</figcaption></figure></section>
    <section className="card"><h2>徐行で増える時間と、車列ができる条件</h2><p>低速で走ることによる時間損失と、処理できる台数を超えて発生する待ち車列を分けて計算します。</p><div className="evidenceGrid"><article><h3>1台の低速走行による追加時間</h3><code>d = 3.6 L (1/v徐行 - 1/v基準)</code><p>Lは区間長m、vはkm/h。減速・再加速は含まない、定速走行の比較です。</p>{[{ label: '徐行区間長', value: length, min: 10, max: 100, set: setLength, unit: 'm' }, { label: '徐行速度の試算値', value: slow, min: 5, max: 20, set: setSlow, unit: 'km/h' }, { label: '比較する通常速度', value: speed, min: 20, max: 60, set: setSpeed, unit: 'km/h' }].map(x => <label className="rangeControl" key={x.label}><span>{x.label}<b>{x.value}{x.unit}</b></span><input type="range" min={x.min} max={x.max} value={x.value} onChange={e => x.set(Number(e.target.value))} /></label>)}<strong className="evidenceNumber">+{fmt(directDelay)} 秒/台</strong><p className="finePrint">「徐行」の法的な意味を固定速度と定義したものではありません。この秒数を下の車列遅れに単純加算しません。</p></article>
    <article><h3>台数を処理できるか</h3><code>開通中の容量 s = 3600 / h</code><code>平均容量 c = s × (C-B) / C</code><p>h＝車頭時間（秒/台）、C＝周期、B＝進入禁止時間（秒）。需要が平均容量以上なら車列が残りやすくなります。</p><label className="rangeControl"><span>片方向の需要（仮定）<b>{demand}台/時</b></span><input type="range" min="0" max="1500" step="50" value={demand} onChange={e => setDemand(Number(e.target.value))} /></label><label className="rangeControl"><span>徐行時の車頭時間（仮定）<b>{headway}秒/台</b></span><input type="range" min="2" max="7" step="0.5" value={headway} onChange={e => setHeadway(Number(e.target.value))} /></label><p>現行の車頭時間5秒、周期240秒、進入禁止45秒、予告停止30秒を仮定。予告案は開通時間の一部に毎車停止を残します。</p><p className="finePrint">速度から車頭時間を自動で推定しません。車頭時間は実際の連続通過を測って較正します。</p></article></div>
    <div className="tableScroll"><table className="comparisonTable"><thead><tr><th>方式</th><th>平均容量</th><th>期間内平均遅れ</th><th>60分後の残留</th></tr></thead><tbody>{results.map(r => <tr key={r.policy}><th>{policyNames[r.policy]}</th><td>{fmt(r.capacity)}台/時</td><td>{fmt(r.meanDelay)}秒/台</td><td>{fmt(r.remaining)}台</td></tr>)}</tbody></table></div><code>Q次 = max(0, Q + (λ - μ) Δt)  期間内平均遅れ = ∫Q(t)dt / 到着台数</code><p className="finePrint">単一踏切・片方向・一定流入・初期車列0の流体モデル。評価60分。終了後の未通過車の遅れ、各車の減速発進、隣接交差点、歩行者、事故リスクは含みません。数値は現地改善率ではありません。詳細な感度分析は「提案・効果検証」へ。</p></section>
    <section className="card empiricalCase"><span className="sectionLabel">PUBLIC OBSERVED CASE</span><h2>公開された実績：黒沢踏切の信号化</h2><div className="placementGrid"><article><small>渋滞長（H26 → H30）</small><strong>1,300 → 0 m</strong></article><article><small>旅行速度（H26 → H30）</small><strong>12 → 40 km/h</strong></article><article><small>公表された運行本数</small><strong>28本 / 日</strong></article></div><p>国土交通省が掲載する秋田県由利本荘市の事例。信号踏切の整備による実績で、周辺条件が異なります。今回の予告装置の実績でも、座間14号の改善予測でもありません。測定条件・比較の詳細は元資料と実施主体に確認が必要です。</p><a href={sources[0][1]} target="_blank" rel="noreferrer">国土交通省の出典を読む</a></section>
    <section className="card"><h2>現地データがそろったら、再計算する</h2><p><b>取得済み：</b>公式駅発車ダイヤ抜粋40件、公開整備事例。<b>未取得：</b>方向別流入交通量、停止・徐行車頭時間、実警報・遮断時刻、最大車列・旅行時間・出口渋滞。</p><ol><li>平日朝夕・日中、休日、両方向を観測し、天候・車種・歩行者を記録。</li><li>到着台数と通過台数を別々に測る。渋滞時の通過台数を需要に置き換えない。</li><li>現行データで車列・旅行時間を再現できるか、別の観測日で検証。</li><li>徐行時の車頭時間は、承認された閉鎖環境や類似設備の観測で検証。</li><li>前後比較は同曜日・同時間帯・列車条件をそろえ、対照区間も比較。</li></ol><a href={observationTemplate} download>現地観測の空テンプレートを保存</a><p className="finePrint">テンプレートには架空の実測値を入れていません。現地の計算結果は、データ取得後に作成します。</p></section>
    <section className="card"><h2>誰に提案するか：座間14号を候補にする場合</h2><ol><li><b>神奈川県・厚木土木事務所東部センター</b>：県道407号の設置、観測、道路管理の相談。道路維持課等への取り次ぎを依頼。</li><li><b>神奈川県警察・交通規制課／所轄警察署</b>：信号・表示の解釈、既存踏切信号機制度、公道実証の交通規制。</li><li><b>小田急電鉄の施設・電気／信号担当</b>：鉄道側情報、保安装置との関係、設備・管理責任。公式窓口から担当へ取り次ぎ依頼。</li><li><b>海老名市の道路・交通担当</b>：地域課題と実証の調整。接続する市道の管理確認。</li><li><b>国土交通省の地方整備局・運輸局、警察庁</b>：地方協議で現行制度の不足を特定した後に、制度課題を整理して相談。</li></ol><p>最初の依頼は「停止免除を認めてください」より、現状観測と監視のみの共同検討。資料・デモ・評価計画を持参し、費用と管理主体を相談します。連絡の送信は行っていません。</p><ul>{sources.map(([label, url]) => <li key={url}><a href={url} target="_blank" rel="noreferrer">{label}</a></li>)}</ul><small>資料確認：2026年10月10日。担当・管轄は相談時に再確認。</small></section>
  </div>;
}
