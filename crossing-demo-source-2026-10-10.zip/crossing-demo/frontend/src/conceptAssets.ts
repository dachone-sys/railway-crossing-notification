const base = import.meta.env.BASE_URL;
export const slowImage = `${base}images/踏切デバイス_徐行と予測時間.png`;
export const installationImage = `${base}images/踏切デバイス_設置イメージ.png`;
