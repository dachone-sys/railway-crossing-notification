import { useEffect, useMemo, useState } from 'react';
import { officialTimetable } from './officialTimetable';
import { arrivalsFor, departureCsv, displayTime, mergeIntervals, parseDepartureCsv } from './timetableModel';
import type { DayType, Departure } from './timetableModel';
import { defaults, policyNames } from './proposalModel';
import type { Policy } from './proposalModel';
import './Experience.css';
import './Overview.css';
import { displayDecision } from './deviceModel';
import ComparisonScene from './ComparisonScene';
import { simulateVehicles, vehicleStats, replayPhase } from './comparisonModel';
import { exportComparisonMovie } from './comparisonMovie';
import StateGallery from './StateGallery';

type Feed = { status: string; message: string; fetched_at?: string; trains?: { train_number: string; from_station: string; to_station: string; generated_at: string | null; age_seconds: number | null; freshness: string; delay_seconds: number }[] };
const fmt = (n: number) => n.toLocaleString('ja-JP', { maximumFractionDigits: 1 });
const policies: Policy[] = ['current', 'notice', 'signal'];
const lineColors = ['#cf5953', '#277fa5', '#38a886'];
const apiOrigin = import.meta.env.VITE_API_ORIGIN || (location.protocol === 'file:' ? 'http://127.0.0.1:8000' : `${location.protocol}//${location.hostname}:8000`);

export default function Experience() {
  const [day, setDay] = useState<DayType>('holiday');
  const [departures, setDepartures] = useState<Departure[]>(officialTimetable.departures);
  const [imported, setImported] = useState(false);
  const [t, setT] = useState(150);
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(3);
  const [upTravel, setUpTravel] = useState(120);
  const [downTravel, setDownTravel] = useState(90);
  const [delay, setDelay] = useState(0);
  const [uncertainty, setUncertainty] = useState(15);
  const [exitBlocked, setExitBlocked] = useState(false);
  const [feedLost, setFeedLost] = useState(false);
  const [stale, setStale] = useState(false);
  const [recovered, setRecovered] = useState(true);
  const [demand, setDemand] = useState(600);
  const [message, setMessage] = useState('');
  const [recording, setRecording] = useState(false);
  const [movieProgress, setMovieProgress] = useState(0);
  const [feed, setFeed] = useState<Feed | null>(null);
  const [feedEnabled, setFeedEnabled] = useState(false);
  const events = useMemo(() => arrivalsFor(departures, day, upTravel, downTravel, delay), [departures, day, upTravel, downTravel, delay]);
  const times = useMemo(() => events.map(e => e.arrival), [events]);
  const effectiveLead = Math.max(30, uncertainty + 12 + 8);
  const fallback = feedLost || stale || !recovered;
  const results = useMemo(() => policies.map(p => simulateVehicles({ demand, stopHeadway: defaults.stopHeadway, slowHeadway: defaults.slowHeadway, dwell: 1, clearance: 12, margin: 8, lead: effectiveLead, horizon: 3600, fallback, blocked: exitBlocked }, p, times)), [times, demand, effectiveLead, fallback, exitBlocked]);
  const phase = replayPhase(t, times, effectiveLead);
  const next = events.find(e => e.arrival + 10 > t);
  const reasons = [exitBlocked ? '出口の収容空間なし' : '', feedLost ? '情報が更新されない' : '', phase === 'closed' ? '仮定上の警報・遮断期間' : '', phase === 'prepare' ? '予告停止期間' : ''].filter(Boolean);
  const warning = next ? next.arrival - 35 - t : null;
  const board = displayDecision({ phase, warningSeconds: warning, uncertainty, replayTime: t, feedLost, stale, exitBlocked, recovered });
  if (board.state === 'gray') reasons.push(board.label);
  const clearanceThreshold = uncertainty + 12 + 8;
  if (warning !== null && warning <= Math.max(30, clearanceThreshold) && warning > 0 && phase === 'normal') reasons.push('予測幅と退出余裕が不足');
  const beforeNow = vehicleStats(results[0], t);
  const afterNow = vehicleStats(results[1], t);
  const delaySaving = beforeNow.meanDelay - afterNow.meanDelay;
  const closedIntervals = mergeIntervals(times.map(a => [Math.max(0, a - 35), Math.min(3600, a + 10)] as [number, number]).filter(([a, b]) => b > a));
  const blockedSeconds = closedIntervals.reduce((sum, [a, b]) => sum + b - a, 0);
  const ymax = Math.max(10, ...results.map(r => r.maxQueue));

  useEffect(() => {
    if (!playing) return;
    const timer = window.setInterval(() => setT(value => Math.min(3600, value + speed / 10)), 100);
    return () => window.clearInterval(timer);
  }, [playing, speed]);
  useEffect(() => {
    if (!feedEnabled) return;
    let disposed = false;
    const controller = new AbortController();
    const poll = async () => {
      try { const response = await fetch(`${apiOrigin}/api/rail-feed`, { signal: controller.signal, cache: 'no-store' }); if (!response.ok) throw new Error(); const result = await response.json() as Feed; if (!disposed) setFeed(result); }
      catch { if (!disposed) setFeed({ status: 'UNAVAILABLE', message: 'APIに接続できません。実ダイヤの再生は利用できます。' }); }
    };
    void poll(); const timer = window.setInterval(() => void poll(), 60000);
    return () => { disposed = true; controller.abort(); window.clearInterval(timer); };
  }, [feedEnabled]);

  const importCsv = async (file?: File) => {
    if (!file) return;
    try {
      if (file.size > 1_000_000) throw new Error('CSVは1MB以内にしてください');
      const parsed = parseDepartureCsv(await file.text());
      if (!parsed.some(d => { const time = Number(d.time.slice(0, 2)); return time === 10; })) throw new Error('この画面の評価範囲（10時台）の列車が必要です');
      setDepartures(parsed); setDay(parsed.some(d => d.day === day && d.time.startsWith('10:')) ? day : parsed.find(d => d.time.startsWith('10:'))!.day); setImported(true); setPlaying(false); setT(0); setMessage(`${parsed.length}件を端末内に取り込みました。出典・収録範囲は利用者の確認が必要です。`);
    } catch (e) { setMessage(e instanceof Error ? e.message : '取り込みに失敗しました'); }
  };
  const exportReport = () => {
    const report = { title: '実駅ダイヤによる踏切PoC再生', version: 'individual-vehicle-comparison-2', exportedAt: new Date().toISOString(), dataset: imported ? '利用者CSV・出典未検証' : officialTimetable.title, day, sources: imported ? [...new Set(departures.map(d => d.sourceUrl))] : officialTimetable.sources, coverage: imported ? '利用者CSV。収録範囲・網羅性・出典は未検証' : officialTimetable.coverage, departures, assumptions: { upTravel, downTravel, addedDelaySeconds: delay, uncertainty, closureBeforeSeconds: 35, closureAfterSeconds: 10, leadSeconds: effectiveLead, requestedLeadSeconds: 30, stopDwellSeconds: 1, clearanceSeconds: 12, marginSeconds: 8, demand, stopHeadway: 5, slowHeadway: 3, horizon: 3600, start: '10:00:00' }, currentReplay: { t, comparison: 'current-vs-notice', reasons, display: board, faults: { feedLost, stale, exitBlocked, recovered } }, estimates: events, results, limitations: ['駅発車時刻は出典のダイヤ。踏切到達・遮断・交通量は仮定', '下り通過列車など未収録。実遮断時間・改善率ではない', '異常条件は比較期間全体に適用。実際の発生時刻に基づく再現ではない', '事故リスク・実設備連動は未検証'] };
    const url = URL.createObjectURL(new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a'); a.href = url; a.download = 'crossing-timetable-report.json'; a.click(); URL.revokeObjectURL(url);
  };

  return <div className="experiencePage" id="top">
    <section className="experienceHero"><div><span className="kicker">CROSSING / REAL TIMETABLE REPLAY</span><h1>列車が来る前に、<br />道路に余裕を。</h1><p>実際の発車ダイヤで、踏切の予告システムを体験する。</p></div><div className="dataBadge"><span className="realTag">{imported ? "取込データ" : "実データ"}</span><strong>{imported ? "利用者CSVのダイヤ" : "小田急の公式時刻表"}</strong><span>{imported ? "出典・収録範囲は未検証" : "平日・土休日 / 2026年3月改正"}</span><small>リアルタイム列車位置・踏切設備は未接続</small></div></section>
    <div className="coverageBanner"><strong>{imported ? '利用者CSVを再生中' : '駅発車ダイヤの一部を再生中'}</strong><span>{imported ? "利用者CSVの時刻を再生。出典・収録範囲・全列車の網羅性は未検証です。踏切の実測情報ではありません。" : officialTimetable.coverage}</span></div>
    <section className="replayLayout">
      <aside className="replayControls"><span className="kicker">01 / PLAY THE DAY</span><h2>時間を動かしてみる</h2><div className="dayButtons"><button className={day === 'holiday' ? 'selected' : ''} onClick={() => { setDay('holiday'); setPlaying(false); }}>土休日</button><button className={day === 'weekday' ? 'selected' : ''} onClick={() => { setDay('weekday'); setPlaying(false); }}>平日</button></div><div className="replayClock">{displayTime(t)}<small>再生時計・日本時間</small></div><div className="playRow"><button className="playButton" onClick={() => { if (t >= 3600) { setT(0); setPlaying(true); } else setPlaying(v => !v); }}>{playing && t < 3600 ? 'Ⅱ 一時停止' : '▶ 再生'}</button><label>速度<select aria-label="再生速度" value={speed} onChange={e => setSpeed(Number(e.target.value))}><option value="1">1倍</option><option value="3">3倍</option><option value="12">12倍</option><option value="30">30倍</option><option value="60">60倍</option></select></label></div><label className="replayScrub">再生位置<input aria-label="再生位置" type="range" min="0" max="3600" step="1" value={t} onChange={e => { setPlaying(false); setT(Number(e.target.value)); }} /></label><div className="phaseJumps">{[['接近前', -100], ['予告', -55], ['遮断開始', -35], ['警報', -25], ['列車通過', 2], ['車列の差', 90]].map(([name, offset]) => <button key={name} onClick={() => { const target = events.find(e => e.arrival >= 100 && e.arrival < 3500); setPlaying(false); setT(Math.max(0, (target?.arrival || 240) + Number(offset))); }}>{name}</button>)}</div><div className="legendChips"><span><i className="realDot" />駅発車：実ダイヤ</span><span><i className="estimateDot" />到達・警報：推定</span></div></aside>
      <article className="scenePanel"><div className="sceneHeader"><div><span className="kicker">02 / SEE THE CROSSING</span><h2>{board.state === 'red' ? (exitBlocked ? '出口の収容空間がない想定' : '警報・遮断の想定期間') : board.state === 'amber' ? '一時停止へ切り替える想定期間' : board.state === 'gray' ? '補助情報が確認できない状態' : '接近まで余裕がある想定期間'}</h2></div><span className={`phasePill ${phase}`}>{board.state === 'red' ? '進入不可の想定' : board.state === 'amber' ? '予告停止' : board.state === 'gray' ? '情報未確認' : '通常領域'}</span></div><div className="pairedScenes"><section><h3>従来：毎車一時停止</h3><p>停止1秒・通過間隔5秒/台を仮定</p><ComparisonScene run={results[0]} t={t} /></section><section><h3>提案：予告＋徐行（将来構想）</h3><p>緑3秒/台 → 黄5秒/台 → 赤は進入禁止</p><ComparisonScene run={results[1]} t={t} /></section></div><div className="liveComparison"><div><span>現在の待ち車列</span><strong>{beforeNow.waiting} → {afterNow.waiting}<small>台</small></strong></div><div><span>現在までに通過した車</span><strong>{beforeNow.cleared} → {afterNow.cleared}<small>台</small></strong></div><div><span>再生開始からの平均遅れの差</span><strong>{fmt(Math.abs(delaySaving))}<small>秒/台{delaySaving < 0 ? '増加' : '短縮'}</small></strong></div></div><div className="colorSequence"><span className="green">緑：警報まで{effectiveLead}秒超・徐行案</span><span className="amber">黄：警報まで{effectiveLead}秒以下・毎車停止</span><span className="red">赤：警報開始・遮断機が下がる</span></div><p className="finePrint">切替の基本値30秒、予測幅{uncertainty}秒＋退出12秒＋余裕8秒から、この条件では{effectiveLead}秒前に黄色。警報は列車到達35秒前と仮定します。両案とも警報まで20秒以下は新たに進入せず、退出時間を確保。灰では徐行案を取り消し、通常の一時停止へ戻します。時間・交通量・車の位置は説明用の仮定です。</p><div className="movieActions"><button className="primaryButton" disabled={recording} onClick={async () => { setRecording(true); setPlaying(false); try { await exportComparisonMovie(results[0], results[1], setMovieProgress); setMessage('比較動画を保存しました（WebM）。'); } catch (e) { setMessage(e instanceof Error ? e.message : '動画出力に失敗しました'); } finally { setRecording(false); } }}>{recording ? `動画を作成中 ${movieProgress}%` : '比較動画を保存（約30秒・WebM）'}</button><small>同じ車両モデルで緑→黄→赤→再開を描画。作成中はこのタブを開いたままにしてください。</small></div></article>
    </section>
    <section className="flowExplainer"><div><b>01</b><span className="realTag">実データ</span><h3>駅を発車</h3><p>公式時刻表の発車時刻を取り込む。</p></div><div><b>02</b><span className="assumptionTag">仮定</span><h3>踏切への到達を推定</h3><p>走行時間と遅延を足し、予測幅を表示。</p></div><div><b>03</b><span className="assumptionTag">仮定</span><h3>警報の前に予告</h3><p>到達35秒前の警報を仮定。警報の{effectiveLead}秒前から一時停止。</p></div><div><b>04</b><span className="assumptionTag">制度検討</span><h3>道路側の条件を確認</h3><p>出口渋滞や情報途絶時は候補を取り消す。</p></div></section>
    <section className="replayLower">
      <article className="card assumptionsCard"><span className="kicker">03 / CHANGE THE ASSUMPTIONS</span><h2>実ダイヤと仮定を分ける</h2>{[
        ['海老名→踏切の走行時間', upTravel, 30, 300, setUpTravel], ['座間→踏切の走行時間', downTravel, 30, 300, setDownTravel], ['追加する遅延（実測ではない）', delay, 0, 180, setDelay], ['到達推定の幅（実測ではない）', uncertainty, 5, 60, setUncertainty],
      ].map(([label, value, min, max, setter]) => <label className="rangeControl" key={String(label)}><span>{String(label)}<b>{Number(value)}秒</b></span><input type="range" aria-label={String(label)} min={Number(min)} max={Number(max)} step="5" value={Number(value)} onChange={e => (setter as (n: number) => void)(Number(e.target.value))} /></label>)}<label className="rangeControl"><span>片方向の道路交通量（仮定）<b>{demand}台/時</b></span><input aria-label="道路交通量" type="range" min="0" max="1600" step="50" value={demand} onChange={e => setDemand(Number(e.target.value))} /></label><div className="faultToggles"><label><input type="checkbox" checked={exitBlocked} onChange={e => setExitBlocked(e.target.checked)} />出口が詰まる</label><label><input type="checkbox" checked={feedLost} onChange={e => { setFeedLost(e.target.checked); if (e.target.checked) setRecovered(false); }} />情報が途絶える</label><label><input type="checkbox" checked={stale} onChange={e => { setStale(e.target.checked); if (e.target.checked) setRecovered(false); }} />古い情報が届く</label></div><button className="recoveryButton" disabled={feedLost || stale || recovered} onClick={() => setRecovered(true)}>異常が解消したことを確認して表示を復旧</button><p className="finePrint">異常条件は車両モデルの60分全体に適用する机上実験です。出口詰まりは進入を停止、通信・古い情報は徐行案を取消。解除後も復旧確認まで補助表示を戻しません。予測幅を変えても、実際の早着・遅延を観測したことにはなりません。</p></article>
      <article className="card upcomingCard"><span className="kicker">DATA / DEPARTURES</span><h2>駅の発車と、踏切到達の推定</h2><div className="tableScroll"><table className="comparisonTable"><thead><tr><th>駅・方向</th><th>駅発車【ダイヤ】</th><th>踏切到達【推定】</th></tr></thead><tbody>{events.filter(e => e.arrival + 10 >= t).slice(0, 7).map(e => <tr key={e.id}><th>{e.station} {e.direction === 'up' ? '上り' : '下り'}<small>{e.kind}</small></th><td>{e.time}</td><td>{displayTime(e.arrival)}</td></tr>)}</tbody></table></div><p className="finePrint">収録：{events.length}本（時刻窓前の列車を含む）。実ダイヤは発車時刻。踏切の通過・警報の実測情報ではありません。</p><div className="sourcesList">{imported && <span>以下は公式サンプルの参考出典。取り込みCSVの出典とは別です。</span>}{imported && [...new Set(departures.map(d => d.sourceUrl))].slice(0,4).map(url => <a key={url} href={url} target="_blank" rel="noreferrer">CSVに記載された出典（未検証） ↗</a>)}{officialTimetable.sources.filter(source => source.day === day).map(source => <a key={source.url} href={source.url} target="_blank" rel="noreferrer">小田急公式：{source.station}{source.direction === 'up' ? '上り' : '下り'} / {source.revision}改正 ↗</a>)}</div><small>出典確認：{officialTimetable.checkedOn} / 更新時は原本を再確認</small></article>
    </section>
    <section className="card realComparison"><div className="comparisonHeading"><div><span className="kicker">04 / COMPARE THE EFFECT</span><h2>同じ車両モデルで、60分の結果を比較</h2></div><button className="primaryButton" onClick={exportReport}>実ダイヤと結果を保存</button></div><p>上の車の動き・車列・通過数と同じ車両単位の計算です。全車の到着・進入・退出時刻を記録します。下り通過列車などは未収録のため現地の改善量ではありません。</p><div className="coverageBanner compact"><strong>遮断想定の合計 {fmt(blockedSeconds)}秒 / 60分</strong><span>下り通過列車未収録のため、現地の遮断時間・改善率ではありません。</span></div><div className="realResultGrid">{results.map((r, i) => <div key={r.policy} style={{ borderTopColor: lineColors[i] }}><span>{policyNames[r.policy]}</span><strong>{fmt(r.meanDelay)}<small>秒</small></strong><p>期間内平均遅れ</p><dl><dt>最大車列</dt><dd>{fmt(r.maxQueue)}台</dd><dt>終了時に残る車</dt><dd>{fmt(r.remaining)}台</dd><dt>期間平均の容量</dt><dd>{fmt(r.capacity)}台/時</dd></dl><small className={r.overloaded ? 'danger' : 'ok'}>{r.overloaded ? '需要が期間平均の容量以上' : '需要は期間平均の容量未満'}</small></div>)}</div><svg className="queueChart" viewBox="0 0 1000 230" role="img" aria-label="駅ダイヤ抜粋と仮定に基づく車両単位モデルの待ち車列推移"><path d="M55 15V190H980" fill="none" stroke="#b6c7cb" /><text x="5" y="20">{fmt(ymax)}台</text>{closedIntervals.map(([a,b], i) => <rect key={i} x={55 + a / 3600 * 920} y="20" width={(b-a)/3600*920} height="170" fill="#e5a57525" />)}{results.map((r, i) => <polyline key={r.policy} points={r.trace.map(v => `${55 + v.t / 3600 * 920},${190-v.q/ymax*160}`).join(' ')} fill="none" stroke={lineColors[i]} strokeWidth="2.5" />)}<path d={`M${55+t/3600*920} 15V190`} stroke="#476677" strokeDasharray="5 3" />{[0,15,30,45,60].map(m => <text key={m} x={55+m/60*920} y="216" textAnchor="middle">{m === 60 ? '11:00' : `10:${String(m).padStart(2,'0')}`}</text>)}</svg><div className="chartLegend">{policies.map((p,i) => <span key={p}><i style={{background:lineColors[i]}} />{policyNames[p]}</span>)}<span>薄橙：警報・遮断の想定区間</span></div><p className="finePrint">初期車列ゼロ、一定間隔の流入、片方向、車両単位モデル。停止1秒・停止車頭時間5秒、徐行車頭時間3秒、退出12秒＋余裕8秒を仮定。平均遅れは停止線到着から進入までの期間内待ち時間÷到着台数です。終了時残留は待ち車両＋通過中車両。将来の待ち時間、接近時の減速・再加速、正式信号の黄・全赤、予測誤差による事故リスクは未評価。概要画面の流体近似とは条件・計算方法が異なります。</p></section>
    <section className="card connectionLab"><div><span className="kicker">NEXT / CONNECT ACTUAL FEEDS</span><h2>実データを増やす</h2><p>追加ダイヤはCSVで端末内に取り込めます。ODPT列車情報の接続口も用意しています。</p></div><div className="importActions"><a href={`data:text/csv;charset=utf-8,${encodeURIComponent(departureCsv(officialTimetable.departures))}`} download="timetable-template.csv">CSV見本を保存</a><label className="uploadButton">CSVを読み込む<input aria-label="時刻表CSVを読み込む" type="file" accept=".csv,text/csv" onChange={e => { void importCsv(e.target.files?.[0]); e.target.value = ''; }} /></label><button onClick={() => { setDepartures(officialTimetable.departures); setImported(false); setMessage('公式ダイヤの抜粋へ戻しました'); }}>公式サンプルに戻す</button><button onClick={() => setFeedEnabled(v => !v)}>{feedEnabled ? 'ODPT接続確認を止める' : 'ODPT接続状況を確認'}</button></div>{message && <p className="importMessage" role="status">{message}</p>}{feedEnabled && <div className="feedStatus" role="status"><strong>{feed?.status || '接続確認中'}</strong><p>{feed?.message || 'ローカルAPIを確認しています'}</p>{feed?.fetched_at && <small>取得時刻：{feed.fetched_at}</small>}{feed?.trains?.slice(0,10).map((train,i) => <p key={i}>列車{train.train_number}：{train.from_station} → {train.to_station} / 生成 {train.generated_at || '不明'} / {train.freshness}</p>)}</div>}<p className="finePrint">APIキーはサーバー側で管理し、ブラウザへ配信しません。ライブ列車情報は別枠で表示し、この再生時計や道路制御には自動で混ぜません。対象事業者の提供項目・更新間隔・利用条件の確認と登録が必要です。</p><div className="odptAttribution"><a href="https://developer.odpt.org/" target="_blank" rel="noreferrer">ODPT開発者登録 ↗</a><p>ODPT接続時の出典：公共交通オープンデータセンター。各事業者は情報の正確性・完全性を保証しません。事業者への直接のお問い合わせはお控えください。ライブデータは現在未接続です。このデモへのお問い合わせはGitHubのIssuesへ。接続時は対象データの利用条件を別途確認します。</p></div></section>
    <StateGallery /><footer className="experienceFooter">公式ダイヤで再生する提案PoC / 現地の通行判断には使えません。</footer>
  </div>;
}

