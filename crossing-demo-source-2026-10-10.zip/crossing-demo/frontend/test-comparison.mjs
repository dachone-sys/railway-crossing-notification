import assert from 'node:assert/strict';
import fs from 'node:fs';import ts from 'typescript';
const js=ts.transpileModule(fs.readFileSync(new URL('./src/comparisonModel.ts',import.meta.url),'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2023,module:ts.ModuleKind.ESNext}}).outputText;
const {simulateVehicles,vehicleStats,gateFraction,replayPhase,minuteCountdown}=await import(`data:text/javascript;base64,${Buffer.from(js).toString('base64')}`);
const p={demand:600,stopHeadway:5,slowHeadway:3,dwell:1,clearance:12,margin:8,lead:35,horizon:3600,fallback:false,blocked:false};
const arrivals=Array.from({length:15},(_,i)=>200+i*240);
const before=simulateVehicles(p,'current',arrivals),after=simulateVehicles(p,'notice',arrivals);
assert.ok(after.meanDelay<before.meanDelay);assert.ok(after.maxQueue<before.maxQueue);
for(const run of [before,after]){
 for(let t=0;t<=3600;t+=.5){const s=vehicleStats(run,t);assert.equal(s.arrived,s.waiting+s.inCrossing+s.cleared);assert.ok(gateFraction(t,arrivals)>=0&&gateFraction(t,arrivals)<=1);if(replayPhase(t,arrivals,p.lead)==='closed')assert.equal(s.inCrossing,0,'all cars clear before warning');}
 for(const v of run.vehicles){if(v.entry===null)continue;assert.ok(v.entry>=v.arrival);assert.ok(!arrivals.some(a=>v.entry>=a-35-p.clearance-p.margin&&v.entry<a+10),'no admission during warning or exit reserve');}
}
const open=[2000];const current=simulateVehicles({...p,horizon:600},'current',open),notice=simulateVehicles({...p,horizon:600},'notice',open);
assert.equal(current.vehicles[0].entry-current.vehicles[0].arrival,1);assert.equal(notice.vehicles[0].entry-notice.vehicles[0].arrival,0);
const fallback=simulateVehicles({...p,fallback:true},'notice',arrivals);assert.deepEqual(fallback.vehicles,before.vehicles);
const blocked=simulateVehicles({...p,blocked:true},'notice',arrivals);assert.equal(blocked.passed,0);assert.equal(blocked.remaining,600);assert.equal(blocked.capacity,0);
assert.equal(replayPhase(130,[200],35),'prepare');assert.equal(replayPhase(129.99,[200],35),'normal');assert.equal(replayPhase(165,[200],35),'closed');assert.equal(gateFraction(165,[200]),0);assert.equal(gateFraction(170,[200]),1);assert.equal(gateFraction(207.5,[200]),.5);assert.equal(gateFraction(210,[200]),0);
assert.equal(gateFraction(207.5,[200,230]),1,'second train keeps barrier down');
assert.equal(minuteCountdown(90),'1分30秒');assert.equal(minuteCountdown(.1),'0分01秒');assert.equal(minuteCountdown(-2),'0分00秒');assert.equal(minuteCountdown(NaN),'時間未確認');
simulateVehicles(p,'notice',[-5,200]);
for(const patch of [{demand:NaN},{clearance:-1},{stopHeadway:0},{horizon:0},{dwell:8}])assert.throws(()=>simulateVehicles({...p,...patch},'notice',arrivals));
const data=JSON.parse(fs.readFileSync(new URL('./public/data/official-timetable.json',import.meta.url),'utf8'));
const times=data.departures.filter(v=>v.day==='holiday').map(v=>{const [h,m,s=0]=v.time.split(':').map(Number);return h*3600+m*60+s-36000+(v.direction==='up'?120:90);}).sort((a,b)=>a-b);
const actualRuns=['current','notice','signal'].map(policy=>simulateVehicles(p,policy,times));
fs.writeFileSync('comparison-evidence.json',JSON.stringify({method:'individual-vehicle-2',assumptions:p,dataset:data.title,coverage:data.coverage,arrivals:times,results:actualRuns.map(({vehicles,params,arrivals,trace,...result})=>({...result,trace})),at300:actualRuns.map(r=>({policy:r.policy,...vehicleStats(r,300)})),limitations:['駅ダイヤ抜粋。通過列車未収録','道路交通・到達・警報時刻は仮定','現地改善率ではない']},null,2));
console.log('PASS: shared arrivals, stop/slow motion, conservation, exit reserve, color/gate boundaries, overlapping trains, fallback and blocked exit.');console.log(actualRuns.map(r=>({policy:r.policy,delay:r.meanDelay,max:r.maxQueue,passed:r.passed})));
