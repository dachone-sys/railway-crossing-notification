import fs from 'node:fs';
import ts from 'typescript';
const mod = async name => {
 const source = fs.readFileSync(new URL(`./src/${name}.ts`, import.meta.url), 'utf8');
 const js = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2023, module: ts.ModuleKind.ESNext } }).outputText;
 return import(`data:text/javascript;base64,${Buffer.from(js).toString('base64')}`);
};
const { defaults, simulate } = await mod('proposalModel');
const { arrivalsFor, mergeIntervals } = await mod('timetableModel');
const data = JSON.parse(fs.readFileSync(new URL('./public/data/official-timetable.json', import.meta.url)));
const summary = r => ({ ...r, trace: undefined });
const policies = ['current','notice','signal'];
const timetable = ['weekday','holiday'].map(day => {
 const events = arrivalsFor(data.departures, day, 120, 90, 0);
 const intervals = mergeIntervals(events.map(e=>[Math.max(0,e.arrival-35),Math.min(3600,e.arrival+10)]).filter(([a,b])=>b>a));
 return { day, records: events.length, estimatedBlockedSeconds: intervals.reduce((s,[a,b])=>s+b-a,0), results: policies.map(policy=>summary(simulate(defaults,policy,events.map(e=>e.arrival)))) };
});
const report = { checkedOn:'2026-10-10', model:'fluid-queue-1', parameters:defaults, periodic:policies.map(p=>summary(simulate(defaults,p))), sensitivity:[300,600,900].flatMap(demand=>[3,4,5].map(slowHeadway=>({demand,slowHeadway,results:policies.map(p=>summary(simulate({...defaults,demand,slowHeadway},p)))}))), timetable, sources:data.sources, empirical:{ crossing:'黒沢踏切', intervention:'信号踏切整備', queueBeforeM:1300,queueAfterM:0,speedBeforeKph:12,speedAfterKph:40,trainsPerDay:28,beforeYear:'H26',afterYear:'H30',source:'https://www.mlit.go.jp/road/sisaku/fumikiri/pdf/jirei_03.pdf'}, limitations:['道路交通量・車頭時間・踏切到達・警報時刻は仮定','下り通過列車等はダイヤ未収録','一定流入・片方向・初期車列0・60分評価','平均遅れは期間内車列面積/全到着台数。終了後の遅れは未計上','実測改善率ではない'] };
fs.writeFileSync(new URL('../docs/quantitative-evidence.json',import.meta.url),JSON.stringify(report,null,2));
console.log(JSON.stringify({periodic:report.periodic,timetable:report.timetable},null,2));
