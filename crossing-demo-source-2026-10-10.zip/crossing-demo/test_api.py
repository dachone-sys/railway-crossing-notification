import unittest
from unittest.mock import patch
from app_v2 import configs, train_timing, safety_status, judge_mode, test_modes, data_source_status

class ApiSafetyTests(unittest.TestCase):
    def setUp(self):
        self.key = 'EBINA-ZAMA14'
        self.old_config = configs[self.key]
        self.old_mode = test_modes[self.key]
        configs[self.key] = {'cycle_seconds': 240, 'train_schedule': [100, 120]}
    def tearDown(self):
        configs[self.key] = self.old_config
        test_modes[self.key] = self.old_mode
    def test_overlapping_train_closures(self):
        state = train_timing(self.key, 105)
        self.assertTrue(state['is_train_passing'])
        self.assertEqual(state['seconds_to_open'], 25)
        self.assertTrue(train_timing(self.key, 115)['is_gate_closed'])
        self.assertFalse(train_timing(self.key, 130)['is_gate_closed'])
    def test_warning_boundary(self):
        self.assertFalse(train_timing(self.key, 64)['is_gate_closed'])
        self.assertTrue(train_timing(self.key, 65)['is_gate_closed'])
    def test_faults_take_priority(self):
        for mode in ['COMMUNICATION_ERROR', 'SENSOR_ERROR', 'OBSTACLE', 'LOW_CONFIDENCE']:
            test_modes[self.key] = mode
            self.assertEqual(judge_mode(train_timing(self.key, 20), safety_status(self.key))[0], 'EMERGENCY_STOP')
    def test_configured_key_does_not_claim_live_feed(self):
        with patch('app_v2.odpt_client.consumer_key', 'test-only'):
            self.assertEqual(data_source_status()['active_source'], 'SIMULATION')
            self.assertEqual(data_source_status()['odpt']['mode'], 'CONFIGURED_NOT_CONNECTED')

if __name__ == '__main__':
    unittest.main()
