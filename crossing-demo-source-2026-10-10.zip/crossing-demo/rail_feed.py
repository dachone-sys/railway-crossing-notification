"""Read-only ODPT feed. Never derives crossing permission from public data."""
import json
import os
import time
import threading
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError

def load_local_settings():
    """Read only named settings; never print secrets or overwrite environment."""
    env_file = Path(__file__).with_name('.env')
    if not env_file.exists():
        return
    allowed = {'ODPT_CONSUMER_KEY', 'ODPT_OPERATOR', 'ODPT_RAILWAY', 'ODPT_FEED_ENABLED'}
    for line in env_file.read_text(encoding='utf-8-sig').splitlines():
        if '=' not in line or line.lstrip().startswith('#'):
            continue
        key, value = line.split('=', 1)
        if key.strip() in allowed:
            os.environ.setdefault(key.strip(), value.strip().strip('\"\''))

def normalize_records(records, now):
    if not isinstance(records, list):
        raise ValueError('Invalid feed shape')
    normalized = []
    frequencies = []
    for record in records[:1000]:
        if not isinstance(record, dict) or record.get('@type') != 'odpt:Train':
            continue
        generated = record.get('dc:date')
        age = None
        if isinstance(generated, str):
            try:
                stamp = datetime.fromisoformat(generated.replace('Z', '+00:00'))
                if stamp.tzinfo:
                    age = (now - stamp).total_seconds()
            except ValueError:
                pass
        frequency = record.get('odpt:frequency')
        frequency = frequency if isinstance(frequency, (float, int)) and 0 < frequency <= 3600 else 60
        frequencies.append(max(60, frequency))
        valid = record.get('dct:valid')
        expired = False
        if isinstance(valid, str):
            try:
                valid_at = datetime.fromisoformat(valid.replace('Z', '+00:00'))
                expired = bool(valid_at.tzinfo and valid_at < now)
            except ValueError:
                expired = True
        freshness = 'UNKNOWN' if age is None else 'STALE' if expired or age < -5 or age > max(120, frequency * 2) else 'RECENT_INFORMATIONAL'
        def label(key):
            value = record.get(key)
            return value.rsplit(':', 1)[-1].split('.')[-1][:100] if isinstance(value, str) else '不明'
        delay = record.get('odpt:delay', 0)
        normalized.append({
            'train_number': label('odpt:trainNumber'), 'from_station': label('odpt:fromStation'),
            'to_station': label('odpt:toStation'), 'generated_at': generated if isinstance(generated, str) else None,
            'age_seconds': round(age, 1) if age is not None else None, 'freshness': freshness,
            'delay_seconds': delay if isinstance(delay, (int, float)) and delay >= 0 else 0,
        })
    return normalized, max(frequencies, default=60)

class RailFeed:
    def __init__(self):
        self.lock = threading.Lock()
        self.cached = None
        self.last_attempt = float('-inf')
        self.interval = 60

    def get(self):
        load_local_settings()
        key = os.getenv('ODPT_CONSUMER_KEY', '')
        enabled = os.getenv('ODPT_FEED_ENABLED', '').lower() == 'true'
        operator = os.getenv('ODPT_OPERATOR', '')
        if not key or not enabled or not operator:
            return {'status': 'UNCONFIGURED', 'message': '未接続：開発者登録・データ提供確認後に.envへAPIキー、事業者ID、利用条件確認済みの有効化設定を保存してください。現在は公式時刻表の再生です。', 'trains': []}
        if not operator.startswith('odpt.Operator:'):
            return {'status': 'INVALID_CONFIG', 'message': '対象事業者IDを公式カタログで確認してください。', 'trains': []}
        with self.lock:
            if self.cached and time.monotonic() - self.last_attempt < self.interval:
                result = dict(self.cached)
                if result['status'] == 'CONNECTED':
                    fetched = datetime.fromisoformat(result['fetched_at'])
                    elapsed = (datetime.now(timezone.utc) - fetched).total_seconds()
                    result['trains'] = [dict(train, age_seconds=None if train['age_seconds'] is None else round(train['age_seconds'] + elapsed, 1), freshness='STALE' if train['age_seconds'] is not None and train['age_seconds'] + elapsed > self.interval * 2 else train['freshness']) for train in result['trains']]
                return result
            self.last_attempt = time.monotonic()
            try:
                filters = {'acl:consumerKey': key, 'odpt:operator': operator}
                railway = os.getenv('ODPT_RAILWAY', '')
                if railway:
                    filters['odpt:railway'] = railway
                # Only the documented standard ODPT v4 endpoint. No arbitrary URLs.
                url = 'https://api.odpt.org/api/v4/odpt:Train?' + urlencode(filters)
                with urlopen(url, timeout=8) as response:
                    raw = response.read(10_000_001)
                if len(raw) > 10_000_000:
                    raise ValueError('Feed too large')
                now = datetime.now(timezone.utc)
                trains, self.interval = normalize_records(json.loads(raw), now)
                self.cached = {'status': 'CONNECTED' if trains else 'EMPTY', 'message': 'ODPT列車情報を取得しました。鮮度は情報表示用であり、安全確率・通行許可ではありません。' if trains else '応答はありましたが対象列車がありません。路線・提供範囲・利用エンドポイントを公式カタログで確認してください。', 'fetched_at': now.isoformat(), 'provider': '公共交通オープンデータセンター', 'operator': operator, 'poll_interval_seconds': self.interval, 'trains': trains}
            except (HTTPError, URLError, TimeoutError, ValueError, OSError):
                # Exceptions can contain the API key in a URL. Never log or return them.
                self.cached = {'status': 'UNAVAILABLE', 'message': '取得できません。認証・対象データ・通信状態を確認してください。古いデータへ自動で切り替えません。', 'trains': []}
            return self.cached

rail_feed = RailFeed()
