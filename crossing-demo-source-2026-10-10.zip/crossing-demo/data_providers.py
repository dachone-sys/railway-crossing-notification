"""External data adapters.

Credentials stay on the server. ODPT availability and operator-specific terms
must be confirmed in the developer catalog before enabling a feed.
"""

import json
import os
from dataclasses import dataclass
from urllib.parse import urlencode
from urllib.request import urlopen


@dataclass(frozen=True)
class ProviderStatus:
    provider: str
    configured: bool
    mode: str
    note: str


class OdptClient:
    def __init__(self, consumer_key: str | None = None, base_url: str = "https://api.odpt.org/api/v4"):
        self.consumer_key = consumer_key or os.getenv("ODPT_CONSUMER_KEY")
        self.base_url = base_url.rstrip("/")

    @property
    def configured(self) -> bool:
        return bool(self.consumer_key)

    def status(self) -> ProviderStatus:
        return ProviderStatus(
            provider="公共交通オープンデータセンター（ODPT）",
            configured=self.configured,
            mode="CONFIGURED_NOT_CONNECTED" if self.configured else "SIMULATION",
            note="登録後のカタログで小田急データの項目・ライセンスを確認してください",
        )

    def fetch(self, resource: str, **filters):
        if not self.consumer_key:
            raise RuntimeError("ODPT_CONSUMER_KEY が設定されていません")
        query = {"acl:consumerKey": self.consumer_key, **filters}
        url = f"{self.base_url}/{resource}?{urlencode(query)}"
        with urlopen(url, timeout=10) as response:
            return json.load(response)

    def fetch_trains(self, operator: str):
        """Fetch odpt:Train records, retaining dc:date for freshness display."""
        return self.fetch("odpt:Train", **{"odpt:operator": operator})


odpt_client = OdptClient()
