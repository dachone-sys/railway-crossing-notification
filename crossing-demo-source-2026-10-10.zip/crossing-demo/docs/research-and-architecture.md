# 実データ化・渋滞モデル設計メモ

調査日: 2026-09-21

## 結論

海老名は実証候補として適しているが、「海老名駅付近の渋滞踏切」と「小田急線」に固定すると実情とずれる。小田急は海老名〜厚木間を2007年度に高架化して2踏切を廃止しており、海老名市の地域公共交通計画は駅周辺の渋滞箇所として主にJR相模線・相鉄線の踏切を挙げている。一方、市内北側には小田急の座間9号・座間14号が実在する。

したがって本システムは、鉄道事業者に依存しない `CrossingProvider`、`TrainFeedProvider`、`RoadSensorProvider` の3層に分け、1つの踏切へ複数データ源を統合する。

## データ源

| データ | 実証段階 | 本番候補 | 注意点 |
|---|---|---|---|
| 踏切位置・属性 | 国交省資料、自治体資料、OpenStreetMapで候補作成 | 鉄道・道路管理者の台帳、現地測量 | OSMや住所代表点だけで保安用途に使わない |
| 列車ダイヤ | 事業者公開時刻表を手入力／許諾取得したGTFS | ODPTまたは事業者契約 | 規約、再配布、キャッシュ期間を確認 |
| リアルタイム列車位置 | シミュレーター | ODPT Challenge/正式API、事業者連携 | 小田急公式アプリの内部通信を解析・転用しない |
| 遮断機状態 | シミュレーター | 鉄道事業者の信号設備との正式連携 | 一般向けIoTセンサーを保安装置として扱わない |
| 道路交通量 | 仮定値 | 路側レーダー、画像解析、車両感知器 | 個人を識別しない。欠測・誤検知を記録 |
| 利用者位置 | 端末内の任意許可 | W3C Geolocation + ジオフェンス | サーバー保存を最小化し、明示同意を得る |

公共交通オープンデータセンターは登録後にAPIキーを発行する。2026チャレンジの協力事業者には小田急電鉄が含まれるが、提供データ項目・利用期限はログイン後のカタログと規約で個別確認が必要。

動的データを一般利用者へ表示する場合、ODPTの開発者ガイドラインはAPIに含まれる生成時刻 `dc:date` の表示を求めている。また、ODPT由来であること、事業者が正確性・完全性を保証しないこと、事業者へ直接問い合わせないこと、開発者の問い合わせ先を示す必要がある。本番UIではこれらをデータ出典パネルに常設する。

- ODPT開発者サイト: https://developer.odpt.org/
- ODPT開発者ガイドライン: https://developer.odpt.org/terms/data_basic_use_guideline.html
- 公共交通オープンデータチャレンジ2026: https://challenge2026.odpt.org/ja/outline.html
- 小田急公式アプリ（列車走行位置を提供）: https://www.odakyu.jp/odakyuapp/
- 国土数値情報: https://nlftp.mlit.go.jp/

## 海老名の候補地点

- 座間9号踏切: 小田急小田原線、海老名市上今泉一丁目付近。国交省の法指定資料と海老名市広報で確認。
- 座間14号踏切: 小田急小田原線、海老名市国分北2-17-3先、県道407号。国交省資料で確認。
- かしわ台1号踏切: 相鉄厚木線。座間14号と近接し、海老名市議会資料では周辺への交通集中が説明されている。

現在アプリに入れた緯度経度は概略表示専用。現地実証ではGNSS測量または管理者台帳で置き換える。

- 海老名市地域公共交通計画: https://www.city.ebina.kanagawa.jp/_res/projects/default_project/_page_/001/003/831/keikakuhonntai.pdf
- 関東地方整備局 踏切道関係資料: https://www.ktr.mlit.go.jp/ktr_content/content/000877863.pdf
- 国交省 法指定資料（座間9号）: https://www.mlit.go.jp/report/press/content/001492088.pdf

## 実装した渋滞モデル

遮断機が閉じている間を道路容量ゼロのボトルネックとする、決定論的ポイントキューモデルを採用した。

記号:

- `Q(t)`: 時刻tの待ち車両数
- `λ`: 車両到着率（台/秒）
- `μ(t)`: 処理率。遮断中は0、開通中は飽和交通流率
- `B`: 警報開始から列車通過、発進損失を含む実効遮断時間

離散時間の更新式:

`Q(t+Δt) = max(0, Q(t) + (λ - μ(t))Δt)`

一定到着・一定飽和流で `μ > λ` のとき:

- 最大車列: `Qmax = λB`
- 開通後の車列解消時間: `td = Qmax / (μ - λ)`
- 総遅れ（車両・秒）: `D = 0.5 λ B² / (1 - λ/μ)`

総遅れは累積到着曲線と累積出発曲線の間の面積に相当する。遮断時間が2倍になると、他条件が同じなら遅れは概ね4倍になる。`λ >= μ` では車列が解消しないため、モデルは不安定として扱う。

現在値は説明用の仮定であり、予測値ではない。実証では最低でも方向別15分交通量、車種構成、遮断時間分布、発進損失、飽和交通流率、近接交差点の信号現示を収集して較正する。

## 研究・技術資料

1. Powell, J. L. (1982), “Effects of Rail-Highway Grade Crossings on Highway Users,” Transportation Research Record 841. 踏切遮断の遅れを解析モデルとマイクロシミュレーションで扱う。https://trid.trb.org/view/181081
2. Port of Los Angeles, “Grade Crossing Delay Calculation Methodology.” 累積到着・出発曲線の三角形面積として総遅れを導出。https://kentico.portoflosangeles.org/getmedia/5799e10d-70b4-4352-8ba0-8e1cd0ea8400/APPENDIX_G3
3. FHWA, *Highway-Rail Crossing Handbook, Third Edition* (2019). 交通量、車種、列車頻度、近接交差点、車列検知、15分ピーク交通量を考慮するよう整理。https://highways.dot.gov/safety/hsip/xings/highway-rail-crossing-handbook-third-edition
4. FRA, *Case Studies to Develop a Highway-Rail Grade Crossing Analysis Framework Using Microsimulation* (2023). 交通需要と観測交通量を区別し、過飽和時や信号連携をモデル化する必要性を説明。https://railroads.dot.gov/elibrary/case-studies-develop-highway-rail-grade-crossing-analysis-framework-using-microsimulation
5. FRA GradeDec. 踏切対策の遅れ、車列、環境・費用便益を比較する公式評価ツール。https://railroads.dot.gov/research-development/program-areas/highway-rail-grade-crossing/gradedec-crossing-evaluation-tool

## 本番アーキテクチャ

1. 収集層: 事業者API、GTFS/時刻表、遮断機信号、道路センサー、気象
2. 正規化層: 事業者固有IDを内部の `crossing_id`、`train_id` に変換
3. 判定層: データ鮮度・複数ソース一致度・フェイルセーフを評価
4. 予測層: 到着時刻、遮断時間、車列、解消時刻を信頼区間付きで算出
5. 配信層: WebSocket（画面）、Web Push（バックグラウンド）、監査ログ
6. UI層: 複数踏切地図、端末内ジオフェンス、アクセシビリティ、PWA

Web PushではVAPID鍵、購読情報保存、失効処理、通知レート制限が必要。位置情報は通知対象の選定を端末内で行い、精密位置をサーバーへ常時送らない構成を優先する。
